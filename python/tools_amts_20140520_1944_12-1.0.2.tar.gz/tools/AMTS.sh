#!/usr/bin/env bash

######################################################################################
# 
# Account Management ToolS (AMTS) - a user account tool for CSO security compliance.
#
#   Target to:      Red Hat Linux
#   Requirement:    python 2.x  (2.6 and later)
#
#   Authors:        Jay Ren          (jr563h@att.com)
#                   Robert Bobkoskie (rb868x@att.com)
#                   (c) CSO, AT&T 2014
#
#######################################################################################
 
# Note:
#   You must set the AMTS_HOME to the AMTS' installation directory,
#   or, you can launch this application from the installation directory itself.
#

# installation directory
AMTSHOME=/usr/local/tools
#AMTSHOME=/users/jr563h/app/tools

# the base directory where the python-xxx is located.
BASEDIR=/usr/local/bin


# launch the application.
if [ -x $BASEDIR/python-sis ]
then 
     $BASEDIR/python-sis  $AMTSHOME/amts_manager/AMTS  $1 $2 $3
elif [ -x $BASEDIR/python-flood ]
then
     $BASEDIR/python-flood $AMTSHOME/amts_manager/AMTS  $1 $2 $3  
elif [ -x $BASEDIR/python ]
then
 	$BASEDIR/python $AMTSHOME/amts_manager/AMTS  $1 $2 $3
elif [ -x /usr/bin/python ]
then
 	$BASEDIR/python $AMTSHOME/amts_manager/AMTS  $1 $2 $3
else
     python $AMTSHOME/amts_manager/AMTS  $1 $2 $3
fi
