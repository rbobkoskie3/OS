#!/usr/bin/env bash

if [ -f /usr/bin/AMTS ] ; then
rm /usr/bin/AMTS
echo '/usr/bin/AMTS removed'
fi

if [ -f /usr/local/bin/AMTS ] ; then
rm /usr/local/bin/AMTS
echo '/usr/local/bin/AMTS removed'
fi


ln -s /usr/local/tools/AMTS.sh /usr/local/bin/AMTS

echo 'A new link is created at /usr/local/bin/AMTS'
