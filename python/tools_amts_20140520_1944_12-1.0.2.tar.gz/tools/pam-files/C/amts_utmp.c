/* 
  read failed logs with timestamp.
  
  Initial Author: Jay Ren
  
  output format:
  
  xyz             |6     |ssh:notty    |1398258801      |mtwptgc01-bge0  |
  
*/

char *_version__ = "1.0.0";

#include<stdio.h>
#include<fcntl.h>
#include<utmp.h>
#include<string.h>

static  int utmp_fd = -1;
static  struct  utmp    utmp_buf;
int debug = 0;
/*
 * setutent - open or rewind the utmp file
 */

void  setutent(void) 
{
    char *fname = "/var/log/btmp";
    if (utmp_fd == -1)
        if ((utmp_fd = open (fname, O_RDWR)) == -1)
            utmp_fd = open (fname, O_RDONLY);

    if (utmp_fd != -1)
        lseek (utmp_fd, (off_t) 0L, SEEK_SET);
}

/*
 * endutent - close the utmp file
 */

void endutent(void)
{
    if (utmp_fd != -1)
        close (utmp_fd);

    utmp_fd = -1;
}

/*
 * getutent - get the next record from the utmp file
 */

struct utmp *getutent(void)
{
    if (utmp_fd == -1)
        setutent ();

    if (utmp_fd == -1)
        return 0;
        
    int sz = sizeof utmp_buf;

    if (debug > 0 )
	printf (" sz = %d ", sz);

    if (read (utmp_fd, &utmp_buf, sz) != sz)
        return 0;

    return &utmp_buf;
}

/*
 * getutline - get the utmp entry matching ut_line
 */

struct utmp *__getutline(const struct utmp *utent)
{
    struct  utmp    save;
    struct  utmp    *new;

    save = *utent;
    while (new = getutent ())
        if (strncmp (new->ut_line, save.ut_line, sizeof new->ut_line))
            continue;
        else
            return new;

    return (struct utmp *) 0;
}



int is_white_space(char *s)
{

    int i;
    for (i =0; i < strlen(s); i++)
    {
        if (s[i] != ' ' || s[i] != '\t')
            return 0;
    }
    return 1;
}
    
    
char *clean_name(char *name)
{
    char *username = name;
    int sz = strlen(username)-1;  
    if (username[sz]=='\n' || username[sz]=='\r')
        username[sz] = 0;
        
    return username;
}

#ifdef INFORMATION
 short int ut_type;            /* Type of login.  */
  pid_t ut_pid;                 /* Process ID of login process.  */
  char ut_line[UT_LINESIZE];    /* Devicename.  */
  char ut_id[4];                /* Inittab ID.  */
  char ut_user[UT_NAMESIZE];    /* Username.  */
  char ut_host[UT_HOSTSIZE];    /* Hostname for remote login.  */
  struct exit_status ut_exit;   /* Exit status of a process marked
                                   as DEAD_PROCESS.  */
/* The ut_session and ut_tv fields must be the same size when compiled
   32- and 64-bit.  This allows data files and shared memory to be
   shared between 32- and 64-bit applications.  */
#if __WORDSIZE == 64 && defined __WORDSIZE_COMPAT32
  int32_t ut_session;           /* Session ID, used for windowing.  */
  struct
  {
    int32_t tv_sec;             /* Seconds.  */
    int32_t tv_usec;            /* Microseconds.  */
  } ut_tv;                      /* Time entry was made.  */
#else
  long int ut_session;          /* Session ID, used for windowing.  */
  struct timeval ut_tv;         /* Time entry was made.  */
#endif

  int32_t ut_addr_v6[4];        /* Internet address of remote host.  */
  char __unused[20];            /* Reserved for future use.  */
};
#endif


int main()
{
    char *s, *c;
    struct utmp *u;
    int i;
    
    setutent();
    u = getutent();
    
    if (debug > 0 )
	printf (" utmp_fd = %d ", utmp_fd);

    while (u != NULL)
    {
    
        if ( !is_white_space(u->ut_user))
        {
            printf ("%-15s |", clean_name(u->ut_user));
            printf ("%-5d |", u->ut_type);
            printf ("%-12s |",  u->ut_line);
            printf ("%-15ld |", u->ut_tv.tv_sec);
            printf ("%-15s |", u->ut_host);                
            printf("\n");
            
         }
         u = getutent();
    }
    
    return 0; 
}
