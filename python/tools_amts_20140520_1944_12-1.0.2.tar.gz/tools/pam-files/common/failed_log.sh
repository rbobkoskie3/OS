#!/usr/bin/env bash 
lastb
