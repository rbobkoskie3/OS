######################################################################
#
# amts_actions.py
#
# Actions on managing user accounts 
#
# Initial Author: Jay Ren
#
######################################################################
import os,sys

from common.locallib import runcmd, systemcall
import shutil, filecmp
import platform
import mod_regex

#import datetime,calendar, re

class  Actions (object):
    
    '''
    Take actions to configure password and login rules.
    
    shell commands:
        chage
    systm module:
        pam
    '''
    
    def __init__(self, usersDB):
        pass
        self.monitor_db = usersDB.monitor_db
        
        self.osname = usersDB.osname      #Linux: 'Linux', Windows:'Windows', Sun:'SunOS'
        self.release = usersDB.release    #Linux: '2.6.18-348.12.1.el5.', Windows:'7.', Sun:'5.10.'
        
    def get_all_att_users(self):
        '''
        Retrieve all att users.
        return rows=
        [{'UserName': u'rb868x', 'UserHome': u'/home/rb868x', 'HostName': u'mtwstdc21', 'UserId': 7192, 'att': 1, 'UserShell': u'/bin/bash', 'FullName': u'Rob Bobkoskie', 'GroupId': 7192}]
        '''
        cmd = ' select HostName,UserName,att, UserId,GroupId,FullName,UserHome,UserShell  from passwdtable where att=1'
        rows = self.monitor_db.execute_dict_query(cmd)

        return rows
    
   #def run_force_reset(self, kk, chage_cmds, username, fullname):

    def run_chage_for_users(self, kk, chage_cmds, list_chage, username, fullname):
        '''
        Run chage command for users
        @param kk:  index for print only
        @param chage_cmds:     a list of chage-commands ['chage ... ', 'chage ...']
        @param username:       one uer name
        @param fillname:       the user's full name.
        
         /usr/bin/passwd -n 7 -w 14 -x 90 hutchib
         passwd -f usernam   <- Force change keeping password aging rules in effect.

         
        '''
        success = True
        for chage_cmd in chage_cmds:
            sys.stdout.write( " [%d] Setting password \'%s\' rule for user \'%s\' (\'%s\')  ----   " % (kk, chage_cmd, username, fullname))
            # execute chage command
            cmd = '%s %s' % (chage_cmd, username)
            rc, stdout, stderr, timeout = runcmd(cmd)
            if (rc != 0):  
                success = False
                print "Failure."
                break
            else:
                print "Success."

        if success:  
            # check the result
            #cmd = r'chage --list %s ' % username
            cmd = r'%s  %s ' % (list_chage, username)
            list_chage
            rc, contents, stderr, timeout = runcmd(cmd)
            if (rc == 0):  
                rslt = [d.strip() for d in contents.splitlines() if d.strip() ] 
                for aline in rslt:
                    print "\t", aline
 

                                       
    def chage_passed_expire(self, expire_or_force, chage_cmds, list_chage, att_users, func_call, excluded_users=[], only_users = [] ):
        '''
        chage_cmds = ['chage -W 7 -I 60 -M 90']
        if only_users == []  do all users
        
        '''
  
        if len(only_users) > 0:
             att_users = self._att_users_with_only_inclusion(att_users, only_users)
        elif len(excluded_users) > 0:
            att_users = self._att_users_with_exclusion(att_users, excluded_users) 
             
        kk = 0
        for row in att_users:
            username = row['UserName']
            fullname = row['FullName']
            kk += 1
            #sys.stdout.write( " [%d] Setting password \'%s\' rule for user \'%s\' (\'%s\')  ----   " % (kk, chage_cmd, username, fullname))
            
            
            func_call( kk, chage_cmds, list_chage, username, fullname)
            


        if only_users != []:
            print '   We only updated password %s for users %s.' % ( expire_or_force, only_users )   
        else:
            print '   We updated password %s for all users.' % expire_or_force
            
        print         
    
            #systemcall(cmd)
    
    # chage -W 7 -I 60 -M 90 bob
       
    
    def _att_users_with_exclusion(self, att_users, excluded_users ):
        '''
        excelude 'excluded_users[] from the att_users.
        
        @param att_users: att_users is a list of dicts.
        @param excluded_users:  a list of users to be excluded from att_users
        @return: only a subset of att_users with exclusion of the excluded_users[]
        
        att_users = [{'UserName': u'rb868x', 'UserHome': u'/home/rb868x', 'HostName': u'mtwstdc21', 'UserId': 7192, 'att': 1, 
                      'UserShell': u'/bin/bash', 'FullName': u'Rob Bobkoskie', 'GroupId': 7192},  ...]  
        '''
        
        for row in att_users:
            username = row['UserName']
            for excl in excluded_users:
                if excl == username:
                    att_users.remove(row)
                    continue
                
        return att_users
    
    def _att_users_with_only_inclusion(self, att_users, only_users ):
        '''
        incelude only 'only_users[] from the att_users.

        @param att_users: att_users is a list of dicts.
        @param excluded_users:  a list of users to be excluded from att_users
        @return: only a subset of att_users with username in the only_users[]
        
        att_users = [{'UserName': u'rb868x', 'UserHome': u'/home/rb868x', 'HostName': u'mtwstdc21', 'UserId': 7192, 'att': 1, 
                      'UserShell': u'/bin/bash', 'FullName': u'Rob Bobkoskie', 'GroupId': 7192},  ...]  
        '''
        
        include_users = []
        for row in att_users:
            username = row['UserName']
            for incl in only_users:
                if incl == username:
                    include_users.append(row)
                    continue
                
        return include_users
        
# http://www.thegeekscope.com/linux-chage-command-to-change-user-expiry-information/
# chage -W 7 bob     -- Set the number of days before the accounting expiry date to issue password change warning.
# chage -I 30 bob    -- Set the number of days after password expiry when the account will be locked
# chage -M 90 bob    -- Set the maximum number of days after which password must be changed. (Calculated from the date when the password was last changed.)

# chage -W 7 -I 60 -M 90 bob

# chage -E -1 bob    -- Remove the expiration date of an account

# locking/unlocking a user: http://www.linuxnix.com/2012/01/unlock-user-account-linux.html



class ConfigPam (object):
    
    def __init__(self):
    
        #linuxstr = platform.linux_distribution()  #LINX ('Red Hat Enterprise Linux Server', '5.9', 'Tikanga')

        # to do - merge with UsersDB.osname.
        supported = {
            'os'  : ['linux', 'sunos'],
            'dist': ['redhat', ''],
            #'version': ['5.*'],
        }
        
        os_supported = dist_supported = version_supported = False
        dist0 = dist1 = ''
        
        try:
            systemstr = platform.system()    #Linux
            if systemstr.lower() in supported['os']:
                os_supported = True
                
            #dist = platform.dist() #('redhat', '5.9', 'Tikanga')
            #dist0 = dist[0].lower()
            #if dist0 in supported['dist']:
            #    dist_supported = True
                
            dist_supported = True
    
            # just for now
            version_supported = True
        except Exception, ex:
            print >> sys.stderr, " Error: check platform error."
            exit(1)
                
            
        msg = ''
        if  not os_supported:
            msg += ' OS \'%s\' is not supported.' % systemstr
        if not dist_supported:
            msg += ' Distribution \'%s\' is not supported.' % dist0
        if not version_supported:
            msg += ' Version \'%s\' is not supported.' % dist1
            
        if msg != '':
            print >> sys.stderr, " Error: %s \n"  % msg
            exit(1)
        
        #print "Dist",  str(platform.dist())   #('redhat', '5.9', 'Tikanga')
        #print "System", platform.system()
        #print  "Machine", platform.machine()  # x86_64
        #print "Uname", platform.uname()    #('Linux', 'mtwstdc21', '2.6.18-348.12.1.el5', '#1 SMP Mon Jul 1 17:54:12 EDT 2013', 'x86_64', 'x86_64')
        #print "Version", platform.version()  ##1 SMP Mon Jul 1 17:54:12 EDT 2013


    def copy_orig_pam_files(self, remote_fname = '/etc/pam.d/system-auth', orig_ext = '.amts_orig'):
        
        ''' 
        save a copy of the orignial pam file.
        '''
                
        try:
            if os.path.exists(remote_fname):     
                # if remote file exists, save a backup file to (.amts_orig)
                remote_orig = remote_fname + orig_ext 
                if not os.path.exists(remote_orig):
                    # now save the remote file to file.orig.
                    shutil.copy( remote_fname, remote_orig  )
                    # double check the file was copied over
                    if not os.path.exists(remote_orig):
                        print >> sys.stderr, "    Error: Failed to copy file \'%s\' to \'%s\' " % (remote_fname, remote_orig)
                        #exit(1)
                        return ''
                    else:
                        print "    Pass: Success to save a  copy of \'%s\' to a backup of \'%s\' " % (remote_fname, remote_orig)
                        return remote_orig
                else:
                    print "    Info: Back up file \'%s\' already exists." % remote_orig    
                    return remote_orig    
            else:
                print >> sys.stderr, "    Error: File \'%s\' does not exist. Check it." % remote_fname
                return ''

        except Exception, ex:
            print >> sys.stderr, "     Error: Can not save a copy of '\%s\' \n" % remote_fname
            
        return ''

   
    def update_pam_files(self, kk,  remote_fname = '/etc/pam.d/system-auth', local_dir = '/usr/local/tools/pam-files/RH5',  remote_orig='', diffs='') :
        '''
        update a remote file by 
           1) check if the remote-file exists.
           2) if exists, check if remote-file.amts_orig exists. if not make a copy to .amts_orig.
           3) check the remote-file.amts_orig is the same as the RH5/orig/local-file (we are supporting RH 5 for now). 
                If not, 
                   print instruction for manual changes and then exit.
                otherwise,
                   copy the local file to the remote file

           @param diffs: the diffs of the two file if done manually.
           @param orig_ent: the extension name of the remote-file's backup file name.
           @return:   0 - success
                      1 - failue
        '''

        remote_base_name = os.path.basename(remote_fname)   #'/etc/pam.d/system-auth'
        
        local_file = '%s/%s' % (local_dir, remote_base_name)    #'../pam-files/RH5/system-auth'
        local_file_orig = '%s/orig/%s' % (local_dir, remote_base_name)
        
        #         
        # make sure the local.orig is identical to the remote.orig
        # if not, it means this os version is not supported.
        #
        msg = self.__is_local_remote_identical(local_file_orig, remote_orig)
        if msg != '':
            print >> sys.stderr, "         Error:  %s\n" % (msg)
            print >> sys.stderr, "         Can not perform an automated update."
            print >> sys.stderr, "         You must update the file \'%s\' manually to ensure the following configurations are satisfied -" % remote_fname
            print >> sys.stderr, "         ", diffs
            return 1
            #exit(1)      
            
                         
        # is the local and remote file already the same.
        msg = self.__is_local_remote_identical(local_file, remote_fname)
        if msg == '':
            print "    Pass: The remote file \'%s\' and the local file \'%s\' are already the same.\n\t  No copy is needed.' "% (remote_fname, local_file)
        else:
            try:
                # now copy local file to the remote.
                shutil.copy( local_file, remote_fname  )
            except Exception, ex:
                 print >> sys.stderr, "    Error: Failed to copy file \'%s\' to \'%s\' " % (local_file, remote_fname)
                 return 1
             
            print "    Pass: Success to copy local file \'%s\' to a remote file \'%s\' " % (local_file, remote_fname)
       
    
        try:
            #print "Copy local to remote ..."
            # if the remote file is different than the local file, copy the local file over
            is_same = filecmp.cmp(local_file, remote_fname)
            if is_same == False:
                shutil.copy(local_file, remote_fname)
                print "    Pass: File \'%s\' copied over to \'%s\'."  % (local_file, remote_fname)
                is_same = filecmp.cmp(local_file, remote_fname)
                if is_same == True:
                    print "    Pass: Success in copying local file  \'%s\' to remote: \'%s\' " % (local_file, remote_fname)
                else:
                    print "    Error: Failure in copying local file  \'%s\'  to remote: \'%s\' " % (local_file, remote_fname)
            else:
                 print "    Pass: Local file \'%s\' is the same as the remote file \'%s\'." % (local_file, remote_fname)
             
        except Exception, ex:
            print >> sys.stderr, "     Error: Failed to copy the local file \'%s\' over to \'%s\' \n" % (local_file,remote_fname)
            return 1
            # exit(1)
        
        return 0  
           
        
    def __is_local_remote_identical(self, local_file_orig, remote_fname):
        '''
        make sure the remote file going to be replaced is the same as what we think it is.
        @param local_file_orig:  full path of the original base file 
        @param remote_fname:   full path of the remote file to be replaced.
        '''
        
        msg = ''
        if not os.path.exists(remote_fname):   
            msg += ' Remote file \'%s\' does not exist error ' %  remote_fname
            
        if not os.path.exists(local_file_orig):   
            msg += ' local-file-orig file \'%s\' does not exist error ' %  local_file_orig
            
        if msg != '':
            return  msg
            
        is_same = filecmp.cmp(local_file_orig, remote_fname)
        
        if is_same == False:
            msg =  " The local file \'%s\' and the remote file \'%s\' do not match.\n\t Either the remote file has already been edited or the OS/version not supported." % (local_file_orig, remote_fname)
            return msg
        
        return msg       
    
    
    def auto_editing(self, remote_fname, editing):
        '''
        Edit a remote_fname file using regex.
        @param editing:   = {
                               'PASS_MAX_DAYS': '90',
                               'PASS_MIN_LEN': '8',
                            }  
        '''
        
        local_tmp = 'conf.tmp'
        diffs = mod_regex.edit_config_file(remote_fname, local_tmp, editing )
        
        if diffs:
            print "    Pass: Success to update the remote file \'%s\'. The diffs are: " %  remote_fname
            mod_regex.print_diffs( diffs, 'diffs:' + remote_fname)
        else:
            print "    Pass: The remote file \'%s\' has already been up to date. " %  remote_fname
           
        
        
        try:
            # now copy local file to the remote.
            shutil.copy( local_tmp, remote_fname  )
            return 0
        except Exception, ex:
            print >> sys.stderr, "    Error: Failed to auto edit file \'%s\' to \'%s\' " % (local_tmp, remote_fname)
            return 1
         
