######################################################################
#
# amts_collect.py
#
# Collect user account information and manage the pam module.
#
# Initial Author: Jay Ren
#
######################################################################
import os,sys

from common.sqlitedb import MODE, Sqlite_DB
from common.locallib import runcmd, systemcall, amIsudoer,yesOrNo
import sqlview.sqlviewer

import datetime,calendar, re
Verbose = 0

CurDir = os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))


class UserAccountDB(object):    
    '''
    Collect user login account information into a sql database, including passwd, shawdow, group, hostips, etc.
    The database is specified in DbFile.
    '''
    def __init__(self, DbFile, entry_limit = 10000, ATT_distanguish=True):
        '''
        Create a db file (DbFile) with tables:
            passwdtable
            shadowtable
            grouptable
            hosttable
            iptable
        and populate them.
        @param DbFile:  the full path of the db file. 
        @param entry_limit:  the limit of entries to a db, for each category, to prevent buffer from overflowing.
        @param ATT_distanguish:    True - distanguish att and not-att ids; False - not care.
        
        shell commmands:
            last
            lastb
            ifconfig
            type
            awk, tr, sort
        
        '''
        self.DbFile = DbFile
        self.hostame = ''    # localhost name populated later
        self.date = datetime.datetime.utcnow()   # utc timestamp
        self.seconds =  calendar.timegm(self.date.utctimetuple())
        self.entry_limit = entry_limit
        self.ATT_distanguish = ATT_distanguish
        
        self.osname = ''     #LINUX, SUN, UNKNOWN 
        self.release = ''    #Linux: '2.6.18-348.12.1.el5.', Windows:'7.', Sun:'5.10.'
            
                
        all_tables = []
        # passwdtable
        passwd_table_val = ['Idx INTEGER PRIMARY KEY',
                     'HostName TXT' , 'UserName TXT' ,'att  INTEGER', 'Passwd TXT', 'UserId TXT', 
                     'GroupId TXT', 'FullName TXT', 'UserHome TXT', 'UserShell TXT', 'LastLogin TXT','LogFrom TXT', 'Duration TXT']
        passwd_table = {'name':'passwdtable',  'fields': passwd_table_val }
        all_tables.append(passwd_table)
        
        #shadowtable
        shadow_table_val = ['Idx INTEGER PRIMARY KEY', 'HostName TXT','UserName TXT', 'Passwd TXT',
                     'LastChanged TXT' , 'MayChange TXT', 'MustChange TXT', 'WarnExpire TXT',
                     'Disabled TXT', 'Disabled70 TXT', 'Reserved TXT']
        shadow_table = {'name':'shadowtable',  'fields': shadow_table_val }
        all_tables.append(shadow_table)
        
        #grouptable
        group_table_val = ['Idx INTEGER PRIMARY KEY', 'datestamp TXT', 'HostName TXT','UserName TXT', 'Passwd TXT',
                     'GroupId TXT' , 'GroupList TXT']
        group_table = {'name':'grouptable',  'fields': group_table_val }
        all_tables.append(group_table)      
      
        #hosttable
        host_table_val = ['Idx INTEGER PRIMARY KEY', 'datestamp TXT', 'HostName TXT','ip TXT','OS TXT','Release TXT', 'Arch TXT','Cpu Txt', 'Python TXT','ssh INTEGER']
        host_table = {'name':'hosttable',  'fields': host_table_val }
        all_tables.append(host_table)      

        ip_table_val = ['Idx INTEGER PRIMARY KEY', 'HostName TXT','ip TXT']
        ip_table = {'name':'iptable',  'fields': ip_table_val }
        all_tables.append(ip_table)      
        
        # failedlogtable
        failedlog_table_val = ['Idx INTEGER PRIMARY KEY','HostName TXT' , 'UserName TXT', 'tty TXT', 'FailedLogin TXT','LogFrom TXT', 'Duration TXT']
        failedlog_table = {'name':'failedlogtable',  'fields': failedlog_table_val }
        all_tables.append(failedlog_table)
        
        ### Create DB File
        try:
            self.monitor_db = Sqlite_DB(dbname = self.DbFile, all_tables=all_tables, db_mode = MODE.Create)
            # chmod 640
        except Exception, ex:
            print >> sys.stderr, 'Failed to create db file \'%s\'' % self.DbFile
            exit(1)
        
       
    def insert_passwd(self, HostName, mypasswd, verbose=False):
        '''
        Insert each user into the passwdtable of the db
        @param HostName:  local hostname
        @param mypassed:  a list of passwds for all users
        @return:   total number of users
        
        mypasswd[0] = mt3253:x:7910:7910::/home/mt3253:/bin/bash

        passwd_table_val = ['Idx INTEGER PRIMARY KEY',
                     'HostName TXT' , 'UserName TXT' ,'att  INTEGER', 'Passwd TXT', 'UserId TXT', 
                     'GroupId TXT', 'FullName TXT', 'UserHome TXT', 'UserShell TXT']
        '''
        
        key = "idx, HostName, UserName, att, Passwd, UserId, GroupId, FullName, UserHome, UserShell, LastLogin,LogFrom, Duration"      
        value = '?,'*key.count(',') + '?'
        keys = "insert into passwdtable (%s) values (%s)" % (key, value)
        
        # get last login time
        #lastlog = {'uname': itm[0], 'from': itm[2], 'date': dat, 'duration': itm[-1]}
        all_lastlogins = self.get_last_logins()

    
        all_values = []
        kk = 0
        for aline in mypasswd:   
            
            lastlogintime = logfrom = duration = ''
    
            passwd_rcd = aline.split( ":" )
            if len(passwd_rcd) != 7: 
                print >> sys.stderr, "       Warning: passwd_rcd length not match: passwd_rcd = <%s> " % passwd_rcd
                continue
            
            username = passwd_rcd[0]
            password = passwd_rcd[1]
            userid = passwd_rcd[2]
            groupid = passwd_rcd[3]
            fullname = passwd_rcd[4]
            userhome = passwd_rcd[5]
            usershell = passwd_rcd[6]
            att = 1
            
            if self.ATT_distanguish == True:
                # check to see if the user name is in compliance with att's convention
                pattern = r'[a-z]{2}[0-9]{3}[a-z0-9]'
                searchObj = re.search( pattern, username)
                if not searchObj:
                    att = 0
                
            # check the last login
            for lastlog in all_lastlogins:

                if lastlog['uname']  == username:
                    lastlog['uname']  == username
                    lastlogintime = lastlog['date'] 

                    logfrom = lastlog['from']      
                    duration = lastlog['duration']    
                    continue
                         
            values = (None,  HostName,username,att,password, userid,groupid,fullname,userhome,usershell, lastlogintime, logfrom, duration) 
            all_values.append(values)
            kk += 1
            
        if verbose: print '\t [passwd - %d]  %s' % ( kk, all_values[0] )
        self.monitor_db.insert_many(keys, all_values)
        
        return kk


    
    def insert_shadow(self, HostName, myshadow, verbose=False):
        '''
        Insert each user into the shadowtable of the db
        @param HostName:  local hostname
        @param myshadow:  a list of shadow for all users
        @return:   total number of users
        
        myshadow[0] = rr458q:$1$mWR.WctF$LxppZSKJJoejyCMLjMjQ5.:15888:0:99999:7:::
        shadow_table_val = ['Idx INTEGER PRIMARY KEY', 'HostName TXT','UserName TXT', 'Passwd TXT',
                     'LastChanged TXT' , 'MayChange TXT', 'MustChange TXT', 'WarnExpire TXT',
                     'Disabled TXT', 'Disabled70 TXT', 'Reserved TXT']
        '''
        key = "idx,  HostName, UserName, Passwd, LastChanged, MayChange, MustChange, WarnExpire, Disabled, Disabled70, Reserved"
        value = '?,'*key.count(',') + '?'
        keys = "insert into shadowtable (%s) values (%s)" % (key, value)
    
        all_values = []
        
        kk = 0
        for aline in myshadow:   
            passwd_rcd = aline.split( ":" )
            if len(passwd_rcd) != 9: 
                print >> sys.stderr,  "!!!!!! Error: shadow_rcd length not match. shadow_rcd=<%s> " % passwd_rcd
                continue
                                       
            values = (None, HostName, passwd_rcd[0], passwd_rcd[1], passwd_rcd[2], passwd_rcd[3], passwd_rcd[4],  passwd_rcd[5],passwd_rcd[6], passwd_rcd[7], passwd_rcd[8])
            all_values.append(values)
            kk += 1
            
        if verbose: print '\t [shadow - %d]  %s' % ( kk, all_values[0] )
        self.monitor_db.insert_many(keys, all_values)
        
        return kk
    
       
    def insert_group(self, HostName, mygroup, verbose=False):
        '''
        Insert each user into the grouptable of the db
        @param HostName:  local hostname
        @param mygroup:  a list of mygroup for all users
        @return:   total number of users
        
        group_table_val = ['Idx INTEGER PRIMARY KEY', 'datestamp TXT', 'HostName TXT','UserName TXT', 'Passwd TXT',
                     'GroupId TXT' , 'GroupList TXT']
        '''
        
        key = "idx,  HostName, UserName, Passwd, GroupId, GroupList"
        value = '?,'*key.count(',') + '?'
        keys = "insert into grouptable (%s) values (%s)" % (key, value)
                    
        all_values = []
        
        kk = 0
        for aline in mygroup:   
            group_rcd = aline.split( ":" )
            if len(group_rcd) != 4: 
                print >> sys.stderr, "      Warning: unknown group_rcd format: group_rcd = \'%s\' " % group_rcd
                continue
                                       
            values = (None,  HostName, group_rcd[0], group_rcd[1], group_rcd[2], group_rcd[3])
            all_values.append(values)
            kk += 1
            
        if verbose: print '\t [group - %d]  %s' % ( kk, all_values[0] )
        self.monitor_db.insert_many(keys, all_values)
        
        return kk
    
    def _get_ipv4_address(self):
        """
        OS dependent. Support Linux RH for now.
        
        Returns IP address(es) of current machine.
        :return:    [u'10.10.109.81', u'172.16.32.74', u'127.0.0.1', u'169.254.95.120']
        
        Linux:
            [root@mtwstdc21 tools]# /sbin/ifconfig -a
              bond0     Link encap:Ethernet  HWaddr E4:1F:13:60:BA:EE
              inet addr:10.10.109.81  Bcast:10.10.109.255  Mask:255.255.255.0
              inet6 addr: fe80::e61f:13ff:fe60:baee/64 Scope:Link
              UP BROADCAST RUNNING MASTER MULTICAST  MTU:1500  Metric:1
              RX packets:789818388 errors:0 dropped:0 overruns:0 frame:0
              TX packets:124959231 errors:0 dropped:0 overruns:0 carrier:0
              collisions:0 txqueuelen:0
              RX bytes:967624705641 (901.1 GiB)  TX bytes:11960554072 (11.1 GiB)
    
              eth0      Link encap:Ethernet  HWaddr E4:1F:13:60:BA:EC
              inet addr:172.16.32.74  Bcast:172.16.32.127  Mask:255.255.255.192
              inet6 addr: fe80::e61f:13ff:fe60:baec/64 Scope:Link
              UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
              RX packets:193188400 errors:0 dropped:0 overruns:0 frame:0
              TX packets:158671129 errors:0 dropped:0 overruns:0 carrier:0
              collisions:0 txqueuelen:1000
              RX bytes:85213023435 (79.3 GiB)  TX bytes:200984690059 (187.1 GiB)
              Interrupt:169 Memory:9a000000-9a012800
        
        Solaris: (not supported yet).
            bash-3.00# /sbin/ifconfig -a
            lo0:1: flags=2001000849<UP,LOOPBACK,RUNNING,MULTICAST,IPv4,VIRTUAL> mtu 8232 index 1
            inet 127.0.0.1 netmask ff000000
            bge0:1: flags=1000843<UP,BROADCAST,RUNNING,MULTICAST,IPv4> mtu 1500 index 2
            inet 10.5.200.33 netmask ffffff80 broadcast 10.5.200.127
        """
        
        rc, ifc_resp, stderr, timeout = runcmd("/sbin/ifconfig -a", shell=True)
        if rc != 0:
            print >> sys.stderr, "  Warning: failed to get local ip interfaces."
            return []
        #print 'AAAA', ifc_resp
          
        patt = re.compile(r'inet\s*\w*\S*:\s*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})')
        #resp = patt.findall(ifc_resp[0])
        resp = patt.findall(ifc_resp)
        #print 'RRRR', resp  # [u'10.10.109.81', u'172.16.32.74', u'127.0.0.1', u'169.254.95.120']


        return resp
    
    def _get_datetime(self, mm, dd, hhmm  ):
        #print mm, dd, hhmm
         
        from time import mktime
         
        today = self.date  #datetime.datetime.now()
        
        date_string = '%s %s %s %s' % (mm, dd, today.year, hhmm)
        date_object = datetime.datetime.strptime(date_string, '%b %d  %Y %H:%M')
        
        if today < date_object:
            date_object = date_object.replace(date_object.year -1)
        
        mydate = date_object.strftime('%Y/%m/%d %H:%M')
        #print 'MMMMMM', mydate
        unixtime = mktime(date_object.timetuple())
        return unixtime

    def _get_datetime_direct(self, mm, dd, hhmm  ):
        
        mydate = '%s %s %s' % (mm, dd, hhmm)

        return mydate

    
    def get_last_logins(self):
        '''
        OS dependent. Support Linux and Sun.
        
        Read last login's date time, from, and duration from /var/logwtmp
        @return:  [{'date': 1398862020.0, 'uname': u'as1190', 'tty': u'ssh:notty', 'from': u'mtwptgc01-bge0', 'duration': u'(00:00)'},...]
        '''
        if Verbose: print " Read last logins ... "
        #cmd = "last -f /var/log/wtmp"
        
                
        #
        #
        # Linux, Sun10
        #
        #
        cmd = '%s/pam-files/common/lastlog.sh' % CurDir
 
        #rc = systemcall('type ' + cmd)
        rc, a,b,c = runcmd(' type ' + cmd, shell=True)
        if rc != 0:
            print >> sys.stderr, " !!!Waring: shell command \'%s\' not found. last-login entries were not collected.!!! " % cmd
            return []
        
        #cmd = "for user in $( awk -F: \'{ print $1}\' /etc/passwd); do last -f /var/log/wtmp $user | head -1 ; done | tr -s \"\n\" |sort"
        #cmd = "for user in $( awk -F: \'{ print $1}\' /etc/passwd); do last $user | head -1 ; done | tr -s \"\n\" |sort"
        #  jr563h   pts/0        mtwptgc01-bge0   Mon Apr 28 19:22   still logged in
        

       
        rc, contents, stderr, timeout = runcmd(cmd, shell=True)
        if rc != 0:
            print >> sys.stderr, "  !!!Warning: get_last_logins: cmd \'%s\' failed. " % (cmd)
            return []
        
        #  pf2624   pts/0        mentat.sims.secu Thu Sep 22 16:06 - 07:56 (3+15:50)
        lastlogins = [d.strip() for d in contents.splitlines() if d.strip() ]    
        
        nn = 0
        all_lastlogins = []
        for aline in lastlogins:
            nn += 1
            #print nn,  aline
            if nn > self.entry_limit:  # prevent overflow error
                print >> sys.stderr, " !!!Warning:  too many last (last login entry entries. ignore the rest (>%d  - %d) ...!!! " % (self.entry_limit,len(lastlogins))
                break
            itm = [d.strip() for d in aline.split(' ') if d.strip() ] 
            #ad0562   pts/0        mtwptgc01-bge0   Tue Sep 18 18:41 - 18:42  (00:00)
            #[u'ad0562', u'pts/0', u'mtwptgc01-bge0', u'Tue', u'Sep', u'18', u'18:41', u'-', u'18:42', u'(00:00)']
            mm = itm[4]
            dd = itm[5]
            hhmm = itm[6]
              

            dat = self._get_datetime_direct(mm, dd, hhmm  )
            lastlog = {'uname': itm[0], 'from': itm[2], 'date': dat, 'duration': itm[-1]}
            #rint lastlog
            all_lastlogins.append(lastlog)
            
        #print "LEN ", all_lastlogins

        return all_lastlogins
        
    def get_failed_logins_linux(self, cmd = 'lastb'):
        '''
        Read failed login's date time, from, and duration from /var/log/btmp
        @return:  [{'date': 1398862020.0, 'uname': u'as1190', 'tty': u'ssh:notty', 'from': u'mtwptgc01-bge0', 'duration': u'(00:00)'},...]
        '''
        
        if Verbose: print " Read failed logins ... "
        #cmd = "for user in $( awk -F: \'{ print $1}\' /etc/passwd); do last -f /var/log/wtmp $user | head -1 ; done | tr -s \"\n\" |sort"
        #cmd = 'last jr563h |head -n 3'
        
        
        rc, a,b,c = runcmd(' type ' + cmd, shell=True)
        if rc != 0:
            print >> sys.stderr, " !!!Waring: shell command \'%s\' not found. Failed-login entries were not collected.!!! " % cmd
            return []
        
        rc, contents, stderr, timeout = runcmd(cmd, shell=True)
        if rc != 0:
            print >> sys.stderr, "cmd \'%s\' failed. " % (cmd)
            return []
            #exit(1)
        
        faildlogins = [d.strip() for d in contents.splitlines() if d.strip() ]    
        
        all_faildlogins = []
        for aline in faildlogins:
            #print  aline
            itm = [d.strip() for d in aline.split(' ') if d.strip() ] 
 
            #[u'ad0562', u'pts/0', u'mtwptgc01-bge0', u'Tue', u'Sep', u'18', u'18:41', u'-', u'18:42', u'(00:00)']
            tty = itm[1]
            mm = itm[4]
            dd = itm[5]
            hhmm = itm[6]
              
            #print "AAAA", aline, len(itm)
            if len(itm) != 10:
                dat = 0
            else:
                dat = self._get_datetime(mm, dd, hhmm  )
            lastlog = {'uname': itm[0], 'from': itm[2], 'tty': tty, 'date': dat, 'duration': itm[-1]}
            #rint lastlog
            all_faildlogins.append(lastlog)
            
        #print all_faildlogins[1]

        return all_faildlogins


    def get_failed_logins_sun10(self, filename = '/var/adm/authlog'):
        '''
        Read failed login's date time, from, and duration from /var/log/btmp
        @return:  [{'date': 1398862020.0, 'uname': u'as1190', 'tty': u'ssh:notty', 'from': u'mtwptgc01-bge0', 'duration': u'(00:00)'},...]
        '''
        
        if Verbose: print " Read failed logins ... "
        #cmd = "for user in $( awk -F: \'{ print $1}\' /etc/passwd); do last -f /var/log/wtmp $user | head -1 ; done | tr -s \"\n\" |sort"
        #cmd = 'last jr563h |head -n 3'
        
        
        faildlogins = self.get_a_file(filename)
        
        all_faildlogins = []
        for aline in faildlogins:
            #print  aline
            itm = [d.strip() for d in aline.split(' ') if d.strip() ] 
            
            count_str = ''
            #print itm
             #May  1 23:16:35 report-zone last message repeated 5 times
            if 'repeated' in itm[-3]:
                #['May', '1', '23:16:35', 'report-zone', 'last', 'message', 'repeated', '5', 'times']
                tty = ' '
                mm = itm[0]
                dd = itm[1]
                hhmm = itm[2][:4]  
                count_str = itm[-2] + '-times'
                #uname = ' '
                fromp = 'repeat-above'
            else:
                # ['May', '1', '23:16:27', 'report-zone', 'sshd[6300]:', '[ID', '800047', 'auth.notice]', 'Failed', 'keyboard-interactive', 'for', 'jr563h', 'from', '135.70.30.179', 'port', '61434', 'ssh2']
                #[u'ad0562', u'pts/0', u'mtwptgc01-bge0', u'Tue', u'Sep', u'18', u'18:41', u'-', u'18:42', u'(00:00)']
                tty = itm[4]
                mm = itm[0]
                dd = itm[1]
                hhmm = itm[2][:4]
                uname = itm[-6]
                fromp = itm[-4]
            
            dat = self._get_datetime(mm, dd, hhmm  )
            lastlog = {'uname': uname, 'from': fromp, 'tty': tty, 'date': dat, 'duration': count_str}
            #rint lastlog
            all_faildlogins.append(lastlog)
            
        #print all_faildlogins[1]

        return all_faildlogins

        
        
    def insert_failed_login(self, HostName, verbose=False):
        '''
        Insert each user into the passwdtable of the db
        @param HostName:  local hostname
        @param mypassed:  a list of passwds for all users
        @return:   total number of users
        
        as       ssh:notty    mtwptgc01-bge0   Thu Apr 24 16:47 - 16:47  (00:00)
         
        failedlog_table_val = ['Idx INTEGER PRIMARY KEY','HostName TXT' , 'UserName TXT', 'tty TXT', 'FailedLogin TXT','LogFrom TXT', 'Duration TXT']
        '''
        
        key = "idx, HostName, UserName, tty, FailedLogin,LogFrom, Duration"      
        value = '?,'*key.count(',') + '?'
        keys = "insert into failedlogtable (%s) values (%s)" % (key, value)
        
        # get last login time
        #lastlog = {'uname': itm[0], 'from': itm[2], 'date': dat, 'duration': itm[-1]}
        #
        #
        # Linux
        #
        #
        

        if self.osname != 'LINUX':
            filename = '/var/adm/authlog'
            all_failedlogins = self.get_failed_logins_sun10(filename)
        else:
            #cmd = '%s/failed_log.sh' % CurDir       
            cmd = '%s/pam-files/common/failed_log.sh' % CurDir

            all_failedlogins = self.get_failed_logins_linux(cmd)

        #  [ {'date': u'17 20:15:08 2012', 'uname': u'btmp', 'duration': u'2012', 'from': u'Tue'}]
        
        all_values = []
        kk = 0
        for failedlog in all_failedlogins:   
            
            failedlogintime = logfrom = duration = ''

            tty = failedlog['tty']
            failedlogintime = failedlog['date'] 
            logfrom = failedlog['from']      
            duration = failedlog['duration']
            username = failedlog['uname']    

            values = (None,  HostName,username, tty, failedlogintime, logfrom, duration) 
            all_values.append(values)
            kk += 1
            
        if verbose: print '\t [passwd - %d]  %s' % ( kk, all_values[0] )
        self.monitor_db.insert_many(keys, all_values)
        
        return kk

 
    
    def discover_local_ips(self, hostname, verbose=False):
        '''
       discover interface ip's and insert to the iptable of the db.
        @param hostname:  local hostname
        @return:   total number of ips
        
        schema - ['Idx INTEGER PRIMARY KEY', 'HostName TXT','ip TXT']
        '''    
        key = "idx,  HostName, ip"
        value = '?,'*key.count(',') + '?'
        keys = "insert into iptable (%s) values (%s)" % (key, value)
    
        all_ips = self._get_ipv4_address()
                    
        all_values = []
        
        kk = 0
        for aip in all_ips:    
                                       
            values = (None,  hostname, aip)
            all_values.append(values)
            kk += 1
            
        if verbose: print '\t [ip - %d]  %s' % ( kk, all_values[0] )
        self.monitor_db.insert_many(keys, all_values)
        
        return kk
    
    def get_passwd( self ):
        '''
        Each field in a passwd entry is separated with ":" colon characters, and are as follows:
    
        [0] Username, up to 8 characters. Case-sensitive, usually all lowercase
    
        [1] An "x" in the password field. Passwords are stored in the ``/etc/shadow'' file.
    
        [2] Numeric user id. This is assigned by the ``adduser'' script. Unix uses this field, plus the following group field, to identify which files belong to the user.
    
        [3] Numeric group id. Red Hat uses group id's in a fairly unique manner for enhanced file security. Usually the group id will match the user id.
    
        [4] Full name of user. I'm not sure what the maximum length for this field is, but try to keep it reasonable (under 30 characters).
    
        [5] User's home directory. Usually /home/username (eg. /home/johnsmith). All user's personal files, web pages, mail forwarding, etc. will be stored here.
    
        [6] User's "shell account". Often set to ``/bin/bash'' to provide access to the bash shell.
    
        eg. smithj:x:561:561:Joe Smith:/home/smithj:/bin/bash
        '''
        return self.get_a_file (filename = '/etc/passwd' )
    
    def get_group( self ):
        '''
        cdrom:x:24:vivek,student13,raj
        _____ _  _      _____
        |    |  |        |
        |    |  |        |
        0    1  2        3
    
        Where,
    
        [0] group_name: It is the name of group. If you run ls -l command, you will see this name printed in the group field.
        [1] Password: Generally password is not used, hence it is empty/blank. It can store encrypted password. This is useful to implement privileged groups.
        [2] Group ID (GID): Each user must be assigned a group ID. You can see this number in your /etc/passwd file.
        [3] Group List: It is a list of user names of users who are members of the group. The user names, must be separated by commas.
        
        '''
        return self.get_a_file (filename = '/etc/group' )
    
    
    def get_shadow(self ):
        '''
         A shadow file is  separated with ":" colon characters, and are as follows:
    
        [0] Username, up to 8 characters. Case-sensitive, usually all lowercase. A direct match to the username in the /etc/passwd file.
    
        [1] Password, 13 character encrypted. A blank entry (eg. ::) indicates a password is not required to log in (usually a bad idea), and a ``*'' entry (eg. :*:) indicates the account has been disabled.
    
        [2] The number of days (since January 1, 1970) since the password was last changed.
    
        [3] The number of days before password may be changed (0 indicates it may be changed at any time)
    
        [4] The number of days after which password must be changed (99999 indicates user can keep his or her password unchanged for many, many years)
    
        [5] The number of days to warn user of an expiring password (7 for a full week)
    
        [6] The number of days after password expires that account is disabled
    
        [7] The number of days since January 1, 1970 that an account has been disabled
    
        [8] A reserved field for possible future use
        
        eg. smithj:Ep6mckrOLChF.:10063:0:99999:7:::
        '''
      
        #contents = sudo ( 'cat /etc/shadow' )
        #shadow = [d.strip() for d in contents.splitlines() if d.strip() and (not '/etc/profile' in d)]                       
        
        return self.get_a_file (filename = '/etc/shadow' )


       
    def get_a_file(self, filename ):
        '''
        Read a file and convert it into a list of lines.
        Exclude lines with '/etc/profile'
        @param filename:  file name to be read
        @return:  a list of lines with white space stripped in two ends.
    
        '''
    
        with open(filename, 'r') as infile:
            #contents = infile.readlines()
            mypasswd = [d.rstrip('\n') for d in infile  if d.strip() and (not '/etc/profile' in d)]                     
        
        return mypasswd
    
            
    def  read_unix_passwd_grp_shadow_to_db(self, ahost, nosudo):    
        '''
        Main routine to scan localhost for login passwd, group and showdow information.
        
        Read accounts, passwd, group and shadow, for all users in one server.
        @param ahost:  hostname 
        @return:   kkp, kks, kkg - total number of records in each category.
        '''    
            
        HostName = self.hostame
       
        # get a list of passwd nd write them to the db
        mypasswd = self.get_passwd()
        kkp = self.insert_passwd(HostName, mypasswd)

        if not nosudo:
            # get a list of shadow and write them to the db
            shadow = self.get_shadow()
            #print shadow[0]
            kks = self.insert_shadow(HostName, shadow)
        else:
            kks = 0

        # get a list of group and write them to the db
        group = self.get_group()
        #print group[0]   
        kkg = self.insert_group(HostName, group)     
       
        return kkp, kks, kkg

    
        
    def scan_and_save_localhost(self,  all_remote_hosts=['localhost'], verbose=False): 
        '''
        Scan the hosts for host information
        where ip and ssh are reserveed.
        @param all_remote_hosts:  only ['localhost'] is taken for the local scan.
        host_table_val = ['Idx INTEGER PRIMARY KEY', 'datestamp TXT', 'HostName TXT','ip TXT',
                          'OS TXT','Release TXT', 'Arch TXT','Cpu Txt', 'Python TXT','ssh INTEGER']
        '''
        import platform
        import multiprocessing
                    
        key = "idx, datestamp, HostName, ip, OS, Release, Arch,Cpu, Python, ssh"
        value = '?,'*key.count(',') + '?'
        keys = "insert into hosttable (%s) values (%s)" % (key, value)
        
        kk = 0
        all_values = []
        remote_HostName = ''
        for ahost in all_remote_hosts:
            
            '''
            rc, stdout, stderr, timeout = runcmd('hostname')
            myHostName = stdout.replace('\n', '')

            sys.stdout.write( "\n Collecting user account informatin in \'%s\'...\n" % ( myHostName))
           
            # get HostName
            myHostName = [d.strip() for d in myHostName.splitlines() if d.strip()]
            self.hostame = myHostName[-1]
            '''
            
            osname = platform.system()      #Linux: 'Linux', Windows:'Windows', Sun:'SunOS'
            dist =  platform.dist()          # Linux: ('redhat', '5.9', 'Tikanga'), widnows:('', '', ''), Sun:('', '', '')
            release = platform.release()     #Linux: '2.6.18-348.12.1.el5', Windows:'7', Sun:'5.10'
            release = release + '.'         # work around sqlites automatic txt to interger conversion

            if osname.lower() == 'linux':
                osname += ' %s'% dist[0]
            
            uname = platform.uname()
                            #Linux: ('Linux', 'mtwstdc21', '2.6.18-348.12.1.el5', '#1 SMP Mon Jul 1 17:54:12 EDT 2013', 'x86_64', 'x86_64')
                            #Windows: ('Windows', 'LT-JAYREN', '7', '6.1.7601', 'AMD64', 'Intel64 Family 6 Model 58 Stepping 9, GenuineIntel')
                            #Sun: ('SunOS', 'report-zone', '5.10', 'Generic', 'sun4u', 'sparc')
            self.hostame = uname[1]             
            #ver = platform.version()  # Linux: '#1 SMP Mon Jul 1 17:54:12 EDT 2013', Windows:'6.1.7601', sun:'Generic'
            arch = platform.machine()    #Linux:'x86_64', Windows: 'AMD64',  Sun:'sun4u'
            #python_ver = sys.version_info   #sys.version_info(major=2, minor=7, micro=3, releaselevel='final', serial=0)
            python_ver =  platform.python_version()     #'2.7.3'
            python_ver = 'v' + python_ver;   # work around sqlites automatic txt to interger conversion
            
            cpu_num = multiprocessing.cpu_count()


            if 'linux' in osname.lower():
                self.osname = 'LINUX'
            elif 'sunos' in osname.lower():
                self.osname = 'SUN'
            else:
                self.osname = 'UNKNOWN' 
                
            arch = self.osname + ',' + arch
                
            
            #self.osname = osname      #Linux: 'Linux', Windows:'Windows', Sun:'SunOS'
            self.release = release    #Linux: '2.6.18-348.12.1.el5.', Windows:'7.', Sun:'5.10.'
            


            kk += 1          
            
            ip = ''
            ssh = 0        
            values = (None, '%d'%(self.seconds), self.hostame, ip, osname, release, arch,cpu_num,python_ver, ssh) 
            #key = "idx, datestamp, HostName, ip, OS, Release, Arch, Python, ssh"

            all_values.append(values)
                
        if verbose: print '\t [hosttable - %d]  %s' % ( kk, all_values[0] )
        self.monitor_db.insert_many(keys, all_values)
        
        return self.hostame            




def verify_only_users(expire_or_force, att_users,  only_users=['as1190,test11']):
    '''
    if only_users is not empty, check these users only.
    '''  
    #att_users = [{'UserName': u'rb868x', 'UserHome': u'/home/rb868x', 'HostName': u'mtwstdc21', 'UserId': 7192, 'att': 1, 'UserShell': u'/bin/bash', 'FullName': u'Rob Bobkoskie', 'GroupId': 7192}, 
     
    users = 'all'
    if only_users: users = only_users
    yes = yesOrNo("You are going to set password %s for users \'%s\'" % (expire_or_force,users))
    if not yes:
        print >> sys.stderr, "  Exiting ..."
        exit(1)
    
    for auser in only_users:
        found = False
        for aattuser in att_users:
            if auser == aattuser['UserName']:
                found = True
                break
        if not found:
            print >> sys.stderr, '  \'%s\' is not a valide user. exit.\n' % auser
            exit(1)
            
    return only_users
