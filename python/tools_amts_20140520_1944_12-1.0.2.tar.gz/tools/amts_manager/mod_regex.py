######################################################################
#
# mod_config.py
#
# modify a configuration file
#
# Initial Author: Jay Ren
#
######################################################################
import sys
import re


def _parse_line_into_key_value(str):
    
    '''
    
    str = '  PASS_MAX_DAYS        90'
    parse the first column as key and the second one as value
    return:  {'key': 'PASS_MAX_DAYS', 'value': '90'}  - success
             {}   - failue
    
    '''

    regex = re.compile("^(?P<key>\w*?)\s+(?P<value>\w*)")

    try:
        r = regex.search(str.strip())

        return r.groupdict()
  
    except Exception, ex:
        #print "EXCEPT", ex
        pass
        
    return {}


   
def _convert_line(aline, editing):
    '''
    Convert an old line with a new-line.
    when a key in the editing is matched, it will:
        1) the old line is commented out with '#-prior AMTS-#'
        2) The new line will have the value replaced with the desired value specified in the editing dictionary.
        3) The new line will have the commented old line appended with the newline.
    eg:
        a line of 'AMTS-#PASS_MAX_DAYS     90' will result in two lines:
            #-prior AMTS-#PASS_MAX_DAYS     90
            PASS_MAX_DAYS   92

    '''
    
    changed = False
    keyvalue = _parse_line_into_key_value(aline)
    if keyvalue == {}:
        return changed, aline
    #print keyvalue
    key = keyvalue['key']
    
    newline = aline
    
    for akey in editing.keys():
        if akey == key:
            value =  keyvalue['value']
            newvalue = editing[akey]
            
            if newvalue != value:
            
                newline = '#-prior AMTS-#' + aline 
                newline += aline.replace(value,newvalue )
                changed = True
                
                #print "newline", changed, newline
    return changed, newline
                        

def edit_config_file(fname_input, fname_output,  editing, a_convert_line_func = _convert_line):
    '''
    Edit a configure file lines
    @param fname_input:  input file name
    @param fname_output: ooutput file name
    @param a_convert_line_func:  a function to do line editing (controlled by editing)
    @return:  diffs
    
    '''
    
    diffs = []
    with open(fname_output, 'w') as fpout:

        with open(fname_input, 'r') as fpin:     
    
            for aline in fpin:
                changed, newline = a_convert_line_func(aline, editing)
                ##sys.stdout.write(newline)
                fpout.write(newline)
                
                if changed:
                    diffs.append(newline)
                
    return diffs
            
def print_diffs( diffs, title = 'diffs'):
            
    print "------------ %s ---------------" % title
    for aline in diffs:
        sys.stderr.write( aline )
    sys.stderr.write( "-----------------------------------")
    print
   
            
if __name__ == '__main__':

    LoginDef = '/etc/login.defs'
    
    Editing = {
               'PASS_MAX_DAYS': '92',
               'PASS_MIN_LEN': '9',
               }
    
    fname_output='test.conf'
    
    diffs = edit_config_file(LoginDef, fname_output, Editing )
    print_diffs( diffs, 'diffs:' + LoginDef)

