######################################################################
#
# pam_config.py
#
# Platform dependent pam configuration file for AMTS.
#
# Initial Author: Jay Ren
#
######################################################################


class PamMode:
    COPY = 1       # copy file over
    AUTO = 2       # do regex editing automatically
    

system_auth_diffs_linux = '''
 \t password    requisite     pam_cracklib.so retry=3 minlen=8 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=0 difok=3
 \t password    sufficient    pam_unix.so md5 shadow nullok try_first_pass remember=6 use_authtok
 \t :
'''
    
              
              
#PASS_MAX_DAYS   90
#PASS_MIN_LEN    8



login_defs_linux_editing = {
               'PASS_MAX_DAYS': '90',
               'PASS_MIN_LEN': '8',
               }  

Remote_Pam_files_linux_ALL = [{'mode': PamMode.COPY, 'file': '/etc/pam.d/system-auth', 'editing': system_auth_diffs_linux},
                              {'mode': PamMode.AUTO, 'file': '/etc/login.defs', 'editing': login_defs_linux_editing},
                             ]
                              
   
   

default_passwd_sun10 = '''
\t MAXWEEKS=13
\t MINWEEKS=0
\t WARNWEEKS=1
\t PASSLENGTH=8
\t:
'''
default_login_sun10 = '''
\t SYSLOG=YES
\t SYSLOG_FAILED_LOGINS=0
\t:
'''
syslog_conf_sun10 = '''
\t auth.notice <Press Tab>  /var/adm/authlog
\t Run# svcadm refresh system/system-log
\t:
'''

pam_conf_sun10 = '''
\t TBD later
\t TBD later
\t:
'''
Remote_Pam_files_Sun10 = {'/etc/default/passwd': default_passwd_sun10,
                          '/etc/default/login':  default_login_sun10,
                          '/etc/syslog.conf':  syslog_conf_sun10,
                          '/etc/pam.conf':  pam_conf_sun10,
                         }                           