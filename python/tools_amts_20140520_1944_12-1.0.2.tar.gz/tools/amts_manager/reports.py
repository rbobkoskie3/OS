######################################################################
#
# reports.py
#
# Create reports for AMTS.
#
# Initial Author: Jay Ren
#
######################################################################

import os,sys
import datetime, time
from common.prettytable import PrettyTable

class  Reports (object):
    
    '''
    Create Reports for AMTS.
    '''
    
    def __init__(self, usersDB, ReportDir, AvaiableReports):
        
        '''
        @param userDB:      User Datbase object
        @param ReportDir:   Report home directory - /var/local/amts'
        
        '''
        self.monitor_db = usersDB.monitor_db     # database pointer
        self.date_str_email_standard = usersDB.date.strftime("%a, %d %b %Y %H:%M:%S +0000")
        
        self.date_str = usersDB.date.strftime('%Y%m%d_%H%M')    # timestamp in the database with string format of: 20140428_2129
        self.yyyy = usersDB.date.year
        self.mm = usersDB.date.month
        self.day = usersDB.date.day
        self.hostame = usersDB.hostame
    
        self.ReportDir = ReportDir      # report home dir.
        
        # all accepted report options.
        self.all_reports = AvaiableReports   #['all', 'failedLogin','attLastLogin','nonAttLastLogin' ]
        
        # create report home if not exist.
        self.create_dir_if_not_exist(ReportDir)


    def create_dir_if_not_exist(self, adir):
        try:
            if not os.path.exists(adir):
                os.makedirs(adir)
        except Exception, ex:
            print >> sys.stderr, "Can not create the report directory \'%s\'  \n" % adir
            exit(1)        
        
    # write report main
    def main_write_requested_reports(self, requested_reports):
        '''
        requested_reports = [ 'failedLogin','attLastLogin','nonAttLastLogin' ]
        '''
        
        dest_dir = os.path.join(self.ReportDir, "%s/%02d" % (self.yyyy, int(self.mm)))
        
        self.create_dir_if_not_exist(dest_dir)
                
                
        
        for category in requested_reports:
            
            file_name = '%s_%s.rpt' % (category, self.date_str)
        
            file_path = os.path.join(dest_dir, file_name)

    
            header = '\n\t\t ============ Report: %s ===========\n\t\t <%s> - %s \n' % (category, self.hostame, self.date_str_email_standard)
            
            all_sqlcmds = {
                'failedLogin': "select Idx, HostName, UserName, tty, LogFrom, strftime('%Y-%m-%d %H:%M',datetime(FailedLogin, 'unixepoch')) as FailedLog, Duration,count(*) as Counts from (select * from failedlogtable order by FailedLogin) group by UserName order by Idx",
                'attLastLogin':'select HostName, UserName, att, FullName, LastLogin,LogFrom, Duration from passwdtable where att=1 order by UserName' ,
                'nonAttLastLogin':"select HostName, UserName, att, FullName, LastLogin,LogFrom, Duration from passwdtable where att=0 order by UserName",
            }
            
            sqlcmd = all_sqlcmds[category] 
            
            
            self.write_one_report(file_path, sqlcmd, header)
            

        
    def write_one_report(self, file_path, sqlcmd, header):
        '''
        return rows=
        [{'UserName': u'rb868x', 'UserHome': u'/home/rb868x', 'HostName': u'mtwstdc21', 'UserId': 7192, 'att': 1, 'UserShell': u'/bin/bash', 'FullName': u'Rob Bobkoskie', 'GroupId': 7192}]
        '''
        
        #chmod
        
        with open(file_path, 'w') as stream:     
        
            rslt, curs = self.monitor_db.execute_cmd_cur(sqlcmd)
            col_names = [cn[0] for cn in curs.description]
            rows = curs.fetchall()
                    
            x = PrettyTable(col_names)
            
            for i in range ( len(col_names)):
                x.align[col_names[i]] = "l" # Left align all names
                
            x.padding_width = 1    
            for row in rows:
                x.add_row(row)
            
            print header
            print (x)
             
            tabstring = x.get_string() + "\n"
        
        
            stream.write(header)
            stream.write(tabstring)
            
            print " Success in writing report to %s.\n " % file_path
        
        #output=open("export.txt","w")
        #output.write("Population Data"+"\n")
        #output.write(tabstring)

        
