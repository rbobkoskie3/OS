######################################################################
#
# sqlmenu.py
#
# Menu.
#
# Initial Author: Jay Ren
#
######################################################################
import sys
import readline # not in windows
sys.path.append('/home/jr563h/work/fab/products') 
# copy from flut-rpt-zn01:dns_tools/dns/DnsSqlMenu.py
from common.prettytable import PrettyTable


from common.configobj import ConfigObj



class SqlMenu:
    """a simple menu system class"""

    def __init__(self, title='menu', prompt='Query-CLI> '):
        '''
        the constructor
        @param tile:  title of the menu
        @param prompt:  prompt for the ineteractive line.
        '''
        self.nl = '\n'        # pick your favourite newline character '\r\n' for m$ lusers (or '|\n') for fun
        self.prefix = ''    # sandwich the key
        self.postfix = ') '    # close the sandwich
        
        # set available maximum characters in the line. # 76 = 80 - (3 + 1)
        # max = default screen char width - (# menu item chars + 1 letter char + 1 end of line space)
        self.maxtextlen = 80 - (len(self.prefix) + len(self.postfix) + 1 + len(self.nl))

        self.title = title    # the menu title
        self.prompt = prompt    # the menu prompt
        self.entries = []    #list of menu items

        # specify stadout and stderr
        self.myout = sys.stdout    # set these if you would like different
        self.myerr = sys.stderr # they need to have a write() method


    def add_entry(self, key, text, sub=None):
        '''
        add entries to our menu:
        @param key:   is single A-Z, a-z letter choice, no duplicates
        @param text:  is text you want to display
        sub is None for regular function
        sub is lambda function or function for something to happen on press
        if the function returns true, then menu returns,
        otherwise it loops in menu
        sub is a built SqlMenu class if you want a sub menu to run and return next
        '''
        # validation for the key and text strings
        if not(type(key) in [type('a')] and type(text) in [type('abc')]):
            self.myerr.write('key and text parameters must be strings' + self.nl)
            raise Exception('key and text parameters must be strings')
            return False

        if len(key) != 1 or len(text) > self.maxtextlen:
            self.myerr.write(('key must be one char, text must be max %d' % self.maxtextlen) + self.nl)
            raise Exception('key must be one char, text must be max %d' % self.maxtextlen)
            return False


        if (ord(key) >= ord('A') and ord(key) <= ord('Z')) or (ord(key) >= ord('a') and ord(key) <= ord('z')):

            # check to avoid duplicate keys
            for x in self.entries:
                if x['key'] == key:
                    self.myerr.write('key must be unique to this menu' + self.nl)
                    raise Exception('key must be unique to this menu')
                    return False

            # TODO: we could add truncation of text if it's too long
            temp = {'key': key, 'text': text, 'sub': sub}
            self.entries.append(temp)
            return True # happy

        else:
            self.myerr.write('bad key for menu entry' + self.nl)
            raise Exception('bad key for menu entry')
            return False

    def prompt_input(self, prompt, prefill=''):
        '''
        Command line editor with histories (arrow key up/down).
        '''
        
        readline.set_startup_hook(lambda: readline.insert_text(prefill))
        try:
            return raw_input(prompt)
        finally:
            readline.set_startup_hook()
      

    def run_interactive(self):
        """
        run the menu interactively, returns selected
        
        return (choice)
            if len(choice) == 1    --  function selection with pre-defiined sql command
            otherwise              --  sql command entered manually.
        
        use prettytable for display the menu.
        """
        
        while True: 
            xx = PrettyTable(['Choice', 'Function Description'])
            xx._set_horizontal_char('=')
            xx._set_vertical_char(' ')
            xx._set_junction_char('=')
            xx.align["Function Description"] = "l" # Left align city names

            #xx.set_style(PrettyTable.PLAIN_COLUMNS)
            ##xx.set_style(11)

            sys.stdout.write(self.title + self.nl) # print title
            for x in self.entries:                 # print menu
                #sys.stdout.write('        ' + self.prefix + x['key'] + self.postfix + x['text'] + self.nl)
                #sys.stdout.write(' AAA       ' + self.prefix +'BBB' + x['key'] + 'CCC' + self.postfix + x['text'] + 'DDD'+ self.nl)
                a = self.prefix + x['key'] + self.postfix
                b =  x['text'] 
                xx.add_row([a, b])

            print xx.get_string(sortby="Choice")
  

            try: # do safe/smart prompt
                answer = '' # safe
                #answer = raw_input(self.prompt)
                answer = self.prompt_input(self.prompt, prefill='')

            except EOFError: #user pressed ^D
                self.myerr.write('you pressed ^D' + self.nl)
                return False

            except KeyboardInterrupt:
                self.myerr.write('you pressed ^C' + self.nl)
                return False

            #self.myerr.write(('you pressed %s\n' % answer) + self.nl) #DEBUG

            answer = answer.strip()
            # validate answer
            if len(answer) > 1:
                #self.myerr.write('invalid menu entry' + self.nl)
                #self.myerr.write(self.nl)
                #continue
                
                return answer   # treated as a sql command entered manually

            # look for answer
            found = False
            for x in self.entries:
                if x['key'] == answer:
                    found = True
                    if type(x['sub']) in [type(None)]:
                        ##print "CKEY ", x['key']
                        return x['key']

                    elif type(x['sub']) in [type(lambda: True)]:
                        # lambda functions that run each time
                        # if they return true, you exit menu
                        # if they return false, stay in menu
                        if x['sub'](): return x['key']
                        else: continue

                    elif type(x['sub']) in [type(SqlMenu())]:
                        #sub menu system
                        self.myout.write(self.nl)
                        recurse = x['sub'].run_interactive()
                        if not(type(recurse) in [type('a')]): recurse = '0'
                        return x['key'] + recurse

            if not(found):
                self.myerr.write('Invalid menu entry' + self.nl)
                self.myerr.write('\07')
                self.myerr.write(self.nl)
                continue




#example code

def __test_printfoo():
    print 'i am printing foo!'
    return False #make it stay and loop

def test():
    '''
    sub = SqlMenu('sub menu', 'enter a letter> ')
    sub.add_entry('x', 'this is x')
    sub.add_entry('y', 'this is y')
    sub.add_entry('z', 'this is z')
    sub.add_entry('q', 'choose `q\' to quit')
    
    
    thing = SqlMenu('main menu\n---------', '\n$ ')
    thing.add_entry('a', 'this is letter a')
    thing.add_entry('b', 'be prepared!')
    thing.add_entry('c', 'the answer is always c (submenu!)', sub)
    thing.add_entry('w', 'loop this menu', lambda: False)
    thing.add_entry('E', 'escape this menu', lambda: True)
    thing.add_entry('p', '__test_printfoo() and loop', __test_printfoo)
    thing.add_entry('q', 'choose `q\' to quit')
    
    
    print 'the chosen letter is: ' + str(thing.run_interactive())
    '''
    
    #example 2
    menua = SqlMenu(title='menu a: animals\n---------------', prompt='|User-Account-Manager |> ')
    menua.add_entry('A', 'a is for alligator')
    menua.add_entry('B', 'b is for baboon')
    menua.add_entry('C', 'c is for cheetah')
    menua.add_entry('P', 'test_printfoo() and loop', __test_printfoo)
    
    menub = SqlMenu('menu b: food\n------------')
    menub.add_entry('a', 'a is for apple')
    menub.add_entry('b', 'b is for banana')
    menub.add_entry('c', 'c is for carrot')
    
    
    menua.add_entry('x', 'goto food menu', menub)
    menub.add_entry('x', 'goto animals menu', menua)
    
    menua.add_entry('q', 'choose `q\' to quit')
    menub.add_entry('q', 'choose `q\' to quit')
    
    rt = menua.run_interactive()
    
    print "RT ", rt
    
     
#menu_item = [('a', 'find dns records', 'sql_cmd'), ('b', 'find dns records b', 'sql_cmd')]  
    
def runsql_interactive_test():
    
    '''
    sqlcommands_file = 'sqlcommand.rules'
    config = ConfigObj(sqlcommands_file)
    software = config['Sql']
    print software
    '''
    
    test()
    
    exit(111)
    
    software_items = {'b': ['Find log file has extensive time of unactivity', "select * from logtable where TestResult != 'OK' limit 10"], 
                     'a': ['get time, sip, dip, question', 'select time, sip, dip, question from dnsamp limit 15'], 
                     'c': ['count', 'select count(*) as counter  from logtable'], 
                     'e': ['edit', ''], 'q': ['quit', '']}

    
    ss = [('a', 'hello'), ('b', 'world'), ('q', 'quit')]

    
    menua = SqlMenu('menu a: run sql command\n---------------')
    
    #for key, value in software_items():
    for key, value in ss:

        print "KEY ", key, value
        
        menua.add_entry( key, value)   
        
    rt = menua.run_interactive()
    
    print "RT ", software[rt]
    
    




    
    
if __name__ == '__main__':
    runsql_interactive_test()