#!/usr/bin/env python-flood
######################################################################
#
# sqlview.py
#
# View Sql database.
#
# Initial Author: Jay Ren
#
######################################################################

import os,sys
MylibDir = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
Configspec_file =   os.path.dirname(os.path.realpath(__file__)) + '/conf/myconfig.spec'
Myprompt = 'Query-CLI> '    #'LocalUsers-CLI> '

sys.path.append(MylibDir) 

import subprocess
from datetime import datetime
try:
    import argparse     # python 2.7
except:
    import common.argparse as argparse # python 2.6

from common.prettytable import PrettyTable
from sqlmenu import SqlMenu

from common.sqlitedb import Sqlite_DB, MODE 
from common.configobj import ConfigObj
from common.validate import Validator
from common.configobj import ConfigObj, flatten_errors , ConfigObjError 

        
class UserInteractive(object):
    
    '''
    shell
        /sbn/getkey   - retired.
        os.system(cmd)
    
    '''
    
    def __init__(self):
        pass
    
    def _write_reslt_to_file(self, fname, mode = 'a', str_rslt = 'ABC'):
        ''' 
        save to report
        '''
        fp = open(fname, mode) 
        fp.write(str_rslt) ## writing the contain dat1  to new.txt
        fp.close() ## File closing after
    
       
    def _list_files_with_pattern(self, local_dir = './', file_pattern = '*.rpt'):
        import glob
        # list all files in the directory
        files =  glob.glob("%s/%s" % (local_dir, file_pattern))
        
        directory = local_dir 
        if files != []:
            directory = os.path.dirname(files[0])
            
        k = 0
        sys.stdout.write( " %s: [" % directory)
        for afile in files:
            directory, filename = os.path.split(afile)
            if k==0: 
                sys.stdout.write( " %s" % filename)    
                k += 1
            else:
                sys.stdout.write( ", %s" % filename)    
        sys.stdout.write( " ]\n" )    

    
    def choice_to_sqlcmd(self, choice, menu_sqlcmds, master_config_file):
        '''
        Get answer from the interactive menu, and execute the command.
        len(choice) == 1    -- run pre-determined sql command
        otherwise           -- run add-hoc
        
        '''
        ##choice = choice.lower()
        if len(choice) == 1:
            if choice == 'q' :
                exit(0)
            elif choice == 'e':
                self.__do_editoring(fname = master_config_file, position='end')
            elif choice == 'h':
                self.__do_help()
            
            # from menu
            cmd =  menu_sqlcmds[choice][1]
        else:
            cmd = choice    # run add-hoc sql cmd entered.
        return cmd
    
    def __do_simple_editoring(self, fname, position='start'):  # or 'end'
        
        #fname = self.config_file
        option = ''
        #editor = os.getenv('EDITOR', 'vi')
        #print(editor, fname)
        
        if position != 'start' and self.editor == 'vi':
            option = '+\$ '
            
        #print "VI ",'%s %s %s' % (self.editor, option, fname)
        subprocess.call('%s %s %s' % (self.editor, option, fname), shell=True)

    def __do_editoring(self, fname,  position='start'):  # or 'end'
        
        self.__do_simple_editoring(fname, position )
        

        # reload menu
        with open(fname, 'rw') as f:
            sss = f.read()
            
        self.config.reload()
        self.sql_section = self.config['Sql']
        ##print self.sql_section
        
        self.menua = SqlMenu(self.menu_prompt, Myprompt)
        
        for key, value in self.sql_section.items():
            #print "KEY ", key, value
            self.menua.add_entry( key, value[0])

    
    def __do_help(self):

        continue_ = os.system('less %s ' % 'help.txt')
        '''
        inputfile  = open ('help.txt', "r")            
        InputReader = inputfile.readlines()
        for aline in InputReader:
            print aline
        self.wait_for_user_hit_key('')
        '''
           
    def wait_for_user_hit_key(self, str_rslt, view_editor, view_save_outfile, view_reportoutdir):
        
        
        ''''
        Wait for a key stroke (akey) followed by an Enter key.
        if akey is 's':  enter a file name to save a report (*.rpt).
        
        str_rslt:   the previous sqlcmd result in a string format.
                    used here only to append to a *.rpt file.
        
        return view_save_outfile
        '''
        #       os.system('read -p "Press any key to continue"') #linux
        #continue_ = os.system('/sbin/getkey -m "Please any key within %d seconds to continue..." -c  10')
        
        #akey = os.system('/sbin/getkey -m "Please any key to continue..." ')
        prompt = 'Hit <Enter> to continue, or <s> and then <Enter> to save and edit in a report file (.rpt) with \'%s\' ... ' % (view_editor)
        if str_rslt == '':
            prompt = 'Hit <Enter> to continue ... '
        keys = raw_input(prompt)
        
        try:
            if len(keys) == 1:
                akey = keys.strip().lower()[0]
                #print "AKEY: ", akey
                
                if akey == 's' : # do_edit
                    if view_save_outfile == None or not os.path.exists(view_save_outfile):
                        
                        # list existing .rpte files
                        self._list_files_with_pattern(local_dir = view_reportoutdir, file_pattern = '*.rpt')
                        
                        # get filename from user
                        while True:
                            sys.stdout.write( "Save to a file - please enter a file name (if already exists, result will be appended): ")
                            desired_file_with_dir  =   raw_input().strip()
                            if desired_file_with_dir != '': break
                        
                        # ensure file extenstion is '.rpt'
                        fileName, fileExtension = os.path.splitext(desired_file_with_dir)
                        if fileExtension != '.rpt':
                            desired_file_with_dir += '.rpt'
                        
                        # ensure it can take both relative file or absolute file path.
                        directory, filename = os.path.split(desired_file_with_dir)
                        if directory == '':
                            view_save_outfile =  view_reportoutdir + '/'  + filename
                        else: 
                            view_save_outfile = desired_file_with_dir
                    
                    # file open at append mode
                    datetime_now = datetime.now()
                    str_rslt = 'Report at: ' + str(datetime_now) + '\n' + str_rslt
                    your_are_insider_editor = '\n!!You are inside %s editor, delete/edit and close with the commands of \'%s\'!!\n' % (view_editor, view_editor)
                    self._write_reslt_to_file( view_save_outfile, 'a', '\n\n' + str_rslt  + '\n\n' + your_are_insider_editor)
                    
                    # launch vi and position cursor to the end of file.
                    self.__do_simple_editoring(view_save_outfile, position = 'end')
        except Exception, ex:
            msg =  "Exception to wait_for_user_hit_key (ignored): %s " % ex
            sys.stdout.write('\07')
            print msg
            
        return view_save_outfile
          
class Utility(object):
    
    def __init__(self):
        pass
    

    def _ensure_dir_exists(self, d):
        ''' 
        check a directory existense,
        if not exist, create one.
        '''
        try:
            #d = os.path.dirname(f)
            if not os.path.exists(d):
                os.makedirs(d)
        except Exception, ex:
            msg = "Error: create a directory : %s" % ex
            print msg
            exit(2)
            
      
    def _utc_to_local(self, timestampValue):  
        '''
         Convert utc time to datetime
        '''
        assert isinstance(timestampValue, str)
    
        # get the UTC time from the timestamp string.
        try:       
            d = datetime.utcfromtimestamp(float(timestampValue))
            #d = datetime.now()
            return d.strftime('%Y-%m-%d %H:%M:%S')
        except Exception, rt:
           print "ERORR: ", rt
           return "Error ------"

            
    def _group_int(self, number):
        '''
        Utility to reformat an integer to a string with commas, for Python pre-2.7
        i.e.  123456789 = 123,456,789
        '''
        s = '%d' % number
        groups = []
        while s and s[-1].isdigit():
            groups.append(s[-3:])
            s = s[:-3]
        return s + ','.join(reversed(groups))
    
    def _walk_dictionaries(self, node):
        '''
        NOT USED.
        walk through the tree of a dictionary
        to find False item. 
        Check configuration result.
        '''
        rt = True
        for key, item in node.items():
            if isinstance(item, dict):
                rt = self._walk_dictionaries(item)
            else:
                #print "KEY:", key, item
                if item == False:
                    return False
        return rt   
        
class SqlViewer(UserInteractive, Utility):
    
    def __init__(self, config_file = 'sqlcommand.rules'):
        
        self.cname = self.__class__.__name__
        self.cname = sys._getframe().f_code.co_filename + '.' + self.cname
        
        self.config_file = config_file
        
        self.save_outfile = None       # the file name to save for report
        
        
        try:
            # read all configurations
            self.make_configurations()
        
            # set sql menu
            self.menu_prompt = '--- Command Menu (arrows for editing previous sql commands, \'h\' to help, \'q\' to quit, \'Enter\' to run.)  ---'  
            self.init_sqlcommand_menu()   
            
            
            # load files to sqlite db.
            if self.InputFileType == 'Sqlite3':   # read the sqlite db
                
                self.sqlite_db = Sqlite_DB(dbname = self.InputFileName, db_mode=MODE.Read)   
                
            elif self.InputFileType == 'CSV':    # :memory:
                import csv

                allTables=[] 
                #header = ["time", "sip", "dip", "protocol", "sport", "dport", "id", "qa", "opcode", "rcode",
                #  "flags", "question", "qtype", "qclass", "section", "rname", "rtype", "rclass", "rttl", "rdata"]
                header = self.input_section['Header']
                atable = {'name': 'data', 'fields': header}
                allTables.append(atable)
                print allTables
                
                self.sqlite_db = Sqlite_DB(dbname = ':memory:', all_tables= allTables, db_mode=MODE.Create)  
                
                insert_key = 'insert into %s values (%s)' % ('data', ','.join(['?']*len(header)))

                all_lines= csv.reader(open(self.InputFileName), delimiter=self.Delimiter)
                self.sqlite_db.insert_many(insert_key, all_lines)
                
            else:
                print "Inputfile type %s is not supported. Exit." % (self.InputFileType)
                exit(1)
 
            
        except Exception, ex:
            msg =  "[%s__SqlViewer:  Failed to start SqlViewer: (%s)]" % (self.cname, ex)
            print msg
            exit(3)
            ##raise MyPatternException(Ex.Error,'__init__', msg)      

    
    def make_configurations(self):
        '''
        Read confgurations from config file.
        '''
        # spec file in the same directory or the main.
        configspec_file = Configspec_file
        try:
            self.config = ConfigObj(self.config_file, configspec=configspec_file, file_error=True)
            #config = ConfigObj(filename, file_error=True)
        except (ConfigObjError, IOError), e:
            print 'Could not read "%s": %s' % (self.config_file, e)
            exit(1)

        try:
            val = Validator()
            results = self.config.validate(val)
            
            # TODO check validation
            '''
            success = self._walk_dictionaries(results)
            #print "SUCCESS ::", success
            if  not success:
                print "Configuration Error: %s" % str(results)
                #exit(1)
            '''
            if results != True:
                for (section_list, key, _) in flatten_errors(self.config, results):
                    if key is not None:
                        print '\nConfiguration File <%s>: The "%s" key in the section "%s" failed validation\n' % (self.config_file, key, ', '.join(section_list))
                    else:
                        print '\nConfiguration File <%s>: The following section was missing:%s \n' % (self.config_file, ', '.join(section_list))
                    exit(1)
            
            # sections
            self.system_section = self.config['System']
            self.input_section  = self.config['Input']
            self.output_section = self.config['Output'] 
            self.sql_section   =  self.config['Sql']
            
            # input file
            self.InputFileName = self.input_section['InputFileName']
            if self.InputFileName[0] == '/':
                print 'aa', self.InputFileName
            else:
                self.InputFileName = os.path.abspath(os.path.join(os.path.dirname(__file__),self.InputFileName)) 

            
            self.InputFileType = self.input_section['InputFileType']   # 
            self.Delimiter     = self.input_section['Delimiter']   # for csv format only
            
            # output format
            self.ConvertCol2DateTime = self.output_section['ConvertCol2DateTime']   # for csv format only
            self.AutoFormat        =  self.output_section['AutoFormat']    
             
            # dir for *.rpt
            reportoutdir_setting= self.system_section['ReportOutDir']
            
            # set prompt
            global Myprompt
            Myprompt = self.system_section['Prompt']
            
            home = reportoutdir_setting[0]   # HOME or other defined in env
            subdir= reportoutdir_setting[1]
            homedir = os.getenv(home)
            if homedir == '':             # fall to the HOME directory if failed.
                homedir = os.getenv('HOME')
            #self.ReportOutDir = homedir + '/' + subdir      # report directory
            self.ReportOutDir = os.path.join(homedir, subdir)     # report directory
            self._ensure_dir_exists(self.ReportOutDir)           
              
        except Exception, ex:
            msg = "\nError: Configuation file <%s>: %s\n" % (self.config_file, ex)
            print msg
            exit(1)

        
        self.editor = os.getenv('EDITOR', 'vi')

        '''
        print self.system_section 
        print self.sql_section
        print tasks
        print self.ReportOutDir
        '''

    def init_sqlcommand_menu(self):
        '''
        Init sql menu with the readings from a configuration file.
        '''

        print "\nLoading from \'%s\'. Please wait ..." % self.InputFileName
        
        #self.menua = SqlMenu('menu a: run sql command\n---------------')
        self.menua = SqlMenu(self.menu_prompt, Myprompt)
        
        for key, value in self.sql_section.items():
            #print "KEY ", key, value
            self.menua.add_entry( key, value[0])

            

    def query_cmd_with_time2date(self, choice, sqlcmd):
        '''
        Query coomand and display with prettytable and convert unix timestamp to datetime format.
        
        '''
        #sqlcmd="select time, sip, dip, question from %s limit 5 " % self.table
        ##print '[%s]: %s'% (choice, sqlcmd.strip())

        ##rslt = self.con.execute(sqlcmd)
        rslt = self.sqlite_db.execute_cmd(sqlcmd)
        names = list(map(lambda x: x[0], rslt.description))

        return names, rslt
        
        
    
    def query_rslt_to_prettytable(self, names, rslt):
        
        ''' 
        return: pretty table string 
        '''
        ii=0     
        #print names
        x = PrettyTable(names)
        for i in range ( len(names)):
            x.align[names[i]] = "l" # Left align all names
        x.padding_width = 1 # One space between column edges and contents (default)
        
        ind = -1
        if self.ConvertCol2DateTime in names:
            ind = names.index(self.ConvertCol2DateTime)
        #print rslt.description
        for row in rslt :
            ii=ii+1
            #print ii,row
            lrow = list(row)
            
            # split the file name from the first column of gzgrep's output
            #if isinstance(lrow[0], str) and ':' in lrow[0]:
            #    (junk, lrow[0]) = lrow[0].split(':')
                
                
            for k in range(len(lrow)):
                if k == ind:
                    lrow[k]= self._utc_to_local( str(lrow[k] ))
            ###print " ",  ii, lrow
            x.add_row(lrow)

        #print x
        str_rslt = str(x) + '\n'
        
        return str_rslt
    
        #terminal = sys.stdout
        #terminal.write(str(x) +'\n')
        

    def query_rslt_to_raw(self, names, rslt):
        '''
        Get query result with the raw delimiter 
        '''
        for item in names:
            sys.stdout.write(str(item) + self.Delimiter)
        sys.stdout.write('\n')
            
        for row in rslt :
            for item in row:
                sys.stdout.write(str(item) + self.Delimiter)
            sys.stdout.write('\n')
            
    def host_summary(self, cmd = 'select HostName, OS, Release, Arch,Cpu, Python from hosttable'):
        '''
        Summary of the localhost
        '''        
        # gather host information 
        names, rslt =  self.query_cmd_with_time2date('T', cmd)      
        
        x = self.query_rslt_to_prettytable(names, rslt)
        print "\n\t ------------- Host Summary -------------"
        print x
        
    
            
    def db_summary(self):
        '''
        Summary of the db with table names and counts.
        '''        
        # a test run only
        test_cmd = 'SELECT type, name  FROM sqlite_master WHERE type=\'table\''
        names, rslt =  self.query_cmd_with_time2date('T', test_cmd)      
        names.append('Count')
        
        x = PrettyTable(names)
        #for i in range ( len(names)):
        x.align['name'] = "l" # right align name names
        x.align['Count'] = "r" # right align count names
        x.padding_width = 1 # One space between column edges and contents (default)

        for row in rslt:
            table_name = row[1]
            #print "ROW", row
            xcount = self.sqlite_db.execute_cmd('SELECT count(*) FROM ' + table_name)
            for xc in xcount:
                #print xc[0]
                scount = str(x)
                icount = int(xc[0])
                count = self._group_int(int(xc[0]))
                lrow = row + (count,)
            #print lrow
            x.add_row(lrow)  
  
        print " --- Database Summary ---"
        print x

    def interactive(self):     
        '''
        Start to get into interactive mode
        '''
        try:
            # show the localhost summary if can
            cmd = 'select HostName, OS, Release, Arch,Cpu, Python from hosttable'
            self.host_summary(cmd)
        except: 
            self.db_summary()
        #self.wait_for_user_hit_key(str_rslt)
        #continue_ = os.system('/sbin/getkey -m "Press any key within %d seconds to continue..." -c  10')
        #print 
        
        while True:
            try:
                choice =  self.menua.run_interactive()
                acmdline = self.choice_to_sqlcmd(choice, self.sql_section, self.config_file)
                
                acmdline = self.menua.prompt_input(self.menua.prompt, prefill=acmdline).strip()
                
                #print acmdline
                names, rslt = self.query_cmd_with_time2date(choice,acmdline)
                str_rslt = self.query_rslt_to_prettytable(names, rslt)
                print str_rslt
                cmdline = "[%s]: %s" % (choice, acmdline)
                self.save_outfile = self.wait_for_user_hit_key(acmdline + '\n' + str_rslt, self.editor, self.save_outfile, self.ReportOutDir)

            except Exception, rt:
                print "Error: %s" % (str(rt))
                

    def automative(self, tasks =['c','a']):
        '''
        Direct queries w/o getting into interactive mode
        '''
        try:
            for choice in tasks:
                aline = self.choice_to_sqlcmd(choice, self.sql_section, self.config_file)
                #print aline
                names, rslt = self.query_cmd_with_time2date(choice,aline)
                if self.AutoFormat == 'raw':
                    self.query_rslt_to_raw(names, rslt)
                else:
                    print self.query_rslt_to_prettytable(names, rslt)


        except Exception, rt:
                print "Error: %s" % (str(rt))
                
               
                
def main( configfile = 'sqlcommand.rules', automative = []):
    
    '''
    dd = datetime.datetime.strptime('20120103_04', '%Y%m%d_%H')
    print dd

    cc = dd + datetime.timedelta(hours= -12)
    
    print cc.strftime("%Y%m%d%H")


    '''
    if not os.path.exists(configfile):
        msg = "Configuration file \'%s\' does not exist. Aborted." % configfile
        print msg
        exit(1) 

    sqlviewer = SqlViewer(configfile)
    
    
    
    if automative == []:
        #start_test_cmd =   'select datestamp, Days, Total from sumtable order by datestamp desc limit 10'
        sqlviewer.interactive()
    else:
        sqlviewer.automative(automative)


    
def main_options( ):
    '''
    Main program of sqlview

    Options:
      --version             show program's version number and exit
      -h, --help            show this help message and exit
      -d YYYYMMDD_HH, --yyyymmdd_hh=YYYYMMDD_HH
                            date time in yyyymmdd_hh
      -p S_PATTERN, --pattern=S_PATTERN
                            search pattern
    '''
 
    usage="Example:  %s -c config.file" % os.path.basename(__file__)
    #parser = argparse.ArgumentParser(description='Dns metadata cli tool.  Contact jr563h@att.com for feedbacks.') 
    parser = argparse.ArgumentParser(description=usage) 
    
    parser.add_argument('-c','--configfile', help='configuration file', required=True)
    #parser.add_argument('--input', type = argparse.FileType('r'), default = '-')

    args = vars(parser.parse_args())
    
    
    config_input = fname = args['configfile']    

    try:
        fname, tasks = config_input.split('[')
        tasks = tasks.replace(']','')
        automative = [e.strip() for e in tasks.split(',')]
    except:
        fname = args['configfile']    
        automative = []

    
    main(fname, automative)


if __name__ == '__main__':
    main_options()

    
    
