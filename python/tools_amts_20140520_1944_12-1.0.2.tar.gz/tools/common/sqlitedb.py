
#!/usr/bin/env python-sis
#####################################################################
#
# sqlitedb.py
#
# $Id: sqlitedb.py $
#
# $Author: jr563h $
#
# Original Author:  Jay Ren
#
#####################################################################

import sqlite3
import os,sys

class MODE(object):
    '''
    db category:
        MODE.Create
        MODE.Read
        MODE.Passive
    '''
    values = ['Create','Read','Passive']

    class __metaclass__(type):
        def __getattr__(self, name):
            return MODE.values.index(name)
        

class Sqlite_DB(object):
    '''
    Init the db connection and insert one or many entries.
    '''

    def __init__(self, dbname, all_tables=[], db_mode = MODE.Read, db_conn = None):
        '''
        Open and connect to the database. If it does not exist, create one with tables.

        dbname:  db file name.
        
        all_table:  list to create tables.   
                    Empty if db_mode != MODE.Create (read only)
        
        db_mode:   MODE.Create - create new tables.  
                   MODE.Read   - read from an existing sqlite db directly
                   MODE.passive - get a db pointer w/o reading or creating.
                   
        db_conn:   in Passive mode, taken db pointer from another application.
        
        
        
        all_tables: information to create all tables. ex:
        
        header = ["time", "sip", "dip", "protocol", "sport", "dport", "id", "qa", "opcode", "rcode",
                  "flags", "question", "qtype", "qclass", "section", "rname", "rtype", "rclass", "rttl", "rdata"]
        atable = {'name': 'data', 'fields': header}
        allTables.append(atable)
        
        or 
            all_tables = [ {'name':'logtable',  'fields': log_table_val },
                            ...
                        }      
            where:
                log_table_val = ['datestamp TXT PRIMARY KEY', 
                     'server TXT' , 'FileName TXT' ,'lastSeen TXT', 'elapse TXT',
                     'Threshold TXT', 'TestResult TXT']
         
        '''

        self.cname = self.__class__.__name__
        self.cname = sys._getframe().f_code.co_filename + '.' + self.cname

        self.dbname = dbname
        self.all_tables = all_tables
        self.__dbconn = None

        rc = 0
        msg = ''
        # open sqlite db
        
        self.__dbconn = db_conn

        if db_mode == MODE.Read:
            
            if not os.path.exists(self.dbname):
                print "File %s does not exist! " % self.dbname
                exit(3)
                
            try:
                ##dbconn = sqlite3.connect('temp.db', isolation_level=None)
                self.__dbconn = sqlite3.connect(self.dbname)
                # You must not use 8-bit bytestrings unless you use a text_factory that can
                # interpret 8-bit bytestrings (like text_factory = str).
                self.__dbconn.text_factory = lambda x: unicode(x, 'utf-8', 'ignore')

                ##self.dbcur = self.__dbconn.cursor()
            except Exception, re:
                rc = 2
                msg =  "[%s.__init__:  Failed (rc=%d) to connect to the database or to create tables. db=%s: (%s)]" % (self.cname, rc, self.dbname, re)
        elif  db_mode == MODE.Create:   # not os.path.exists(self.dbname):  
            try:
                self.__dbconn = sqlite3.connect(self.dbname)
                # You must not use 8-bit bytestrings unless you use a text_factory that can
                # interpret 8-bit bytestrings (like text_factory = str).
                self.__dbconn.text_factory = lambda x: unicode(x, 'utf-8', 'ignore')
                
                #print "Creatng Tables ..."
                self.__createTable()

                ##self.dbcur = self.__dbconn.cursor()
            except Exception, re:
                rc = 1
                msg =  "[%s.__init__:  Failed (rc=%d) to connect to the database or to create tables. db=%s: (%s)]" % (self.cname, rc, self.dbname, re)

        else: 
            pass

        if rc > 0:
            raise Exception(msg)



    def __createTable(self):
        ''' Creates alarms table in the alarms database

        log_table_val = ['datestamp TXT PRIMARY KEY', 
                     'server TXT' , 'FileName TXT' ,'lastSeen TXT', 'elapse TXT',
                     'Threshold TXT', 'TestResult TXT']
        
        log_table = {'name':'logtable',  'fields': log_table_val }
        '''
        
        ### db.execute("CREATE TABLE  test(id int, data text)")
        if self.__dbconn:

            for atable in self.all_tables:
                
                #print "\t Create table ", atable
                curr = self.__dbconn.cursor()
     
                cmd0 = 'CREATE TABLE IF NOT EXISTS ' + atable['name'] + '('
                #print "CM ", cmd0
                cmd0 += ",".join(atable['fields']) + ')'
    
                try:
                    #print "CMD ", cmd0
                    curr.execute(cmd0)
                    
                except Exception, re:
                    msg =  "[%s__createTable:  Failed to create the alarms tables. db=%s: (%s)]" % (self.cname, self.dbname, re)
                    raise Exception(msg)
                finally :
                    self.__dbconn.commit()
        else:
            msg =  "[%s.__createTable: No database connection to db=%s: (%s)]" % (self.cname, self.dbname, re)
            raise Exception(msg)
            

    def __insertRecord(self, tablename, keys, values ):

        #cmd = "INSERT OR REPLACE INTO %s (%s) VALUES (%s)" % ( tablename, keys, values)
        cmd = "INSERT INTO %s (%s) VALUES (%s)" % ( tablename, keys, values)
        # cmd:  INSERT OR REPLACE INTO logtable (datestamp, server) VALUES ( '12345', 'row[0]')

        
        print "cmd: ", cmd
        # do the insertion
        cur = self.__dbconn.cursor()

        try:
            cur.execute(cmd)
        except Exception, re:
            msg =  "[%s.insertRecord: Failed to add record into db=%s: (%s)]" % (self.cname, self.dbname, re)
            raise Exception(msg)
 
        finally:
            self.__dbconn.commit()

        dip_id = cur.lastrowid

        ##print "INSERT:", cmd
        return dip_id


    def dbclose(self):
        self.__dbconn.close()

    def insert_many(self, keys, values):
        '''
        bulk inserts.
            key = 'datestamp, server, FileName,lastSeen, elapse, Threshold, TestResult'
            value = '?,?,?,?,?,?,?'
            keys = "insert or replace into logtable (%s) values (%s)" % (key, value)
            
        
            all_values = []
            ii = 1
            for row in self.log_table:
            
               values = ('%d'%ii, row[0], row[1], row[2], row[3], row[4], row[5])
               all_values.append(values)
               ii += 1
    
            # insert to the db
            self.monitor_db.insert_many(keys, all_values)

        '''

        try:
            #print "INSERT MANY"

            con = self.__dbconn
            #print "KEYS: ", keys
            #print "VALUES: ", values
            #con.executemany("insert into person(c1,c2,c3,c4,c5,c6,c7) values (?, ?, ?, ?, ?, ?, ?)", persons=[(...), (...), ...])
            con.executemany(keys, values)
            con.commit()

        except Exception, re:
            msg =  "[%s.insert_many: Failed to insert_many record into: db=%s: (%r)]" % (self.cname, self.dbname, re)
            #msg += values
            raise Exception(msg)
            #logging.info('alarddb.insert_many_err', msg)
            
    def execute_cmd(self, cmd):

        cur = self.__dbconn.cursor()

        try:
            rslt = cur.execute(cmd)
        except Exception, re:
            msg =  "[%s.execute_cmd: Failed to execute cmd=\'%s\': (%s)]" % (self.cname, cmd, re)
            raise Exception(msg)
        finally:
            self.__dbconn.commit()

        return rslt
   
    def execute_cmd_cur(self, cmd):

        cur = self.__dbconn.cursor()

        try:
            rslt = cur.execute(cmd)
        except Exception, re:
            msg =  "[%s.execute_cmd: Failed to execute cmd=\'%s\': (%s)]" % (self.cname, cmd, re)
            raise Exception(msg)
        finally:
            self.__dbconn.commit()

        return rslt, cur
     
    
    def __dict_factory(self, cursor, row):
        d = {}
        for idx, col in enumerate(cursor.description):
            d[col[0]] = row[idx]
        return d
    
    def execute_dict_query(self, cmd):
        '''
        Query to return a list of dictionary
        e.g.
          rows = [{'UserName': u'rb868x', 'UserHome': u'/home/rb868x',  'FullName': u'Rob Bobkoskie', 'GroupId': 7192},
                  ...]
        '''

        con = self.__dbconn  #sqlite3.connect(":memory:")
        
        con.row_factory = self.__dict_factory
        cur = con.cursor()
        cur.execute(cmd)
        rows = cur.fetchall()
        #print 'www', rows
        return rows

        #print cur.fetchone()


############# TEST MAIN ######################
if __name__ == '__main__':

    monitor_db = Sqlite_DB(dbname = '/users/jr563h/work/db/exampledb')  # db_mode=MODE.Read)
    #monitor_db.test()
    #monitor_db.test_results()
    monitor_db.close()
