#!/usr/bin/env python-sis
######################################################################
#
# locallib.py
#
# Local libaray functions.
#
# Initial Author: Jay Ren
#
######################################################################

import subprocess, shlex
from threading import Timer
import os, sys


class cd:
    '''
    Context manager for changing the current working directory
    example:
        import subprocess # just to call an arbitrary command e.g. 'ls'

        # enter the directory like this:
        with cd("~/Library"):
           # we are in ~/Library
           subprocess.call("ls")
    
    '''
    def __init__(self, newPath):
        self.newPath = newPath

    def __enter__(self):
        self.savedPath = os.getcwd()
        os.chdir(self.newPath)

    def __exit__(self, etype, value, traceback):
        os.chdir(self.savedPath)
        

def ____________run_cmd (cmd):
    """
    run a system command
    cmd -  ['ls', '-l', ..]
    """
    #assert type(hosts) in types.StringTypes, 'Wrong type for [hosts], should be a string [was {0}]'.format(type(hosts))
    
    
    p = subprocess.Popen(args, bufsize=100000, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # wait until finished
    # get output
    standard_out, standard_err = p.communicate()
    
    return  standard_out, standard_err
    

def __kill_proc(proc, timeout):
    timeout["value"] = True
    proc.kill()


def runcmd(cmd, timeout_sec=300, shell = False):
    '''
    run system command with timeout
    '''
    
    if shell == False:
        cmd = shlex.split(cmd)
    proc = subprocess.Popen(cmd, bufsize=100000, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=shell)
    #proc = subprocess.Popen([cmd], bufsize=100000, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    timeout = {"value": False}
    timer = Timer(timeout_sec, __kill_proc, [proc, timeout])
    timer.start()
    stdout, stderr = proc.communicate()
    timer.cancel()
    
    return proc.returncode, stdout.decode("utf-8"), stderr.decode("utf-8"), timeout["value"]


   
def amIsudoer():
    
    rc, stdout, stderr, timeout = runcmd('cat /etc/shadow')
    
    if rc != 0:
        return False
    
    return True


def systemcall(cmd):
    '''
    system call without waiting for stdout and stderr.
    '''

    #status = subprocess.call(shlex.split(cmd), shell=True)
    status = subprocess.call([cmd], shell=True)
    return status


def yesOrNo( prompt):
    '''
    prompt y/n and wait for an answer
    '''
    yes = set(['yes','y', 'ye'])
    choice = ''
    while choice == '':
        sys.stderr.write( "\n %s [y/n] " % prompt)
        choice= raw_input().lower()

    if choice in yes:
        return True
    else: 
        return False
    
if __name__ == '__main__':   
    
    cmd = r'python-sis /home/jr563h/work/fab/products/sqlview/sqlviewer.py  -c /home/jr563h/work/fab/products/sqlview/conf/manageuser.conf' 
    cmd = r'/home/jr563h/work/fab/products/sqlview/runuser' 
    #cmd = 'ls'
    
    #os.system(cmd)
    
    status = systemcall(cmd)
    print 'Status ', status
    
    
    exit(111)
    rc, stdout, stderr, timeout = runcmd(cmd)
    print stdout