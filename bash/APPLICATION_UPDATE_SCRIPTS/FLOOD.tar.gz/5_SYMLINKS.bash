#! /usr/bin/env bash

ln -s /usr/local/bin/python2.7 /usr/local/bin/python-flood
ln -s /usr/local/bin/python2.7 /usr/local/bin/python-sis
ln -s /usr/local/bin/python2.7 /usr/local/bin/python-fathom
ln -s /usr/local/bin/python2.7-config /usr/local/bin/python-config
ln -s /usr/bin/perl /usr/local/bin/perl-flood

