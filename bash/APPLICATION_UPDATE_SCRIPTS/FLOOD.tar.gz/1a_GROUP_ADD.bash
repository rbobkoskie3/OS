#! /usr/bin/env bash

groupadd -g 2206 sgeadmin
groupadd -g 2205 sis
groupadd -g 2101 flood
groupadd -g 2105 floodxfr
groupadd -g 2200 floodcod
groupadd -g 2202 floodadm
groupadd -g 2203 floodanl
groupadd -g 2204 floodshr
groupadd -g 2207 lifeguard
