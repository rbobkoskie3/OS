#! /usr/bin/env bash

# ID: rb868x 248 Jun 21 10:21 curlWebphoneDB.bash
# Tested on Red Hat 5.3, Solaris 10


#######################################
curl -O "ftp://thprod37.sbc.com/{suits.dat,osuits.dat}"
#######################################


