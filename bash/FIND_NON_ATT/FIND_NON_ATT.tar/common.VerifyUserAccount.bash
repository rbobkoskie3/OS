#! /usr/bin/env bash

# ID: rb868x 423 Jun 21 10:50 common.VerifyUserAccount.bash
# Tested on Red Hat 5.3, Solaris 10


#######################################
# TIMESTAMP=`echo $(date +%Y%m%d-%H%M%S)`
# TMP=/tmp/TMP_$TIMESTAMP
OUTPUT_OSUITS_ATTUID=/tmp/OUTPUT_OSUITS_ATTUID.txt
OUTPUT_SUITS_ATTUID=/tmp/OUTPUT_SUITS_ATTUID.txt
OUTPUT_NOMATCH_ATTUID=/tmp/OUTPUT_NOMATCH_ATTUID.txt
#######################################


